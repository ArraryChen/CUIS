addpath('E:\BaiduNetdiskDownload\CFF_rationality_analysis\CFF_rationality_analysis\tools\CCF');


CUIS_CCF_method2_array= [];
for i = 1:1000
    im = imread(['E:\BaiduNetdiskDownload\UIE\Dataset-CUIS\CUIS-2\CUIS-2\fusion-based-2\',num2str(i),'.png']);
    quality = CCF(im);
    CUIS_CCF_method2_array = [CUIS_CCF_method2_array,quality];
    fprintf('end %d\n',
     i);
end

disp(mean(CUIS_CCF_method2_array));
save('CUIS_CCF_method2_array','CUIS_CCF_method2_array');

