addpath('E:\BaiduNetdiskDownload\CFF_rationality_analysis\CFF_rationality_analysis\tools\CCF');
%E:\BaiduNetdiskDownload\UIE\Dataset-CUIS\CUIS-2\CUIS-2\fusion-based-1\
%E:\BaiduNetdiskDownload\CUIS-CCF-new\CUIS-CCF\CUIS-slight-CCF

CUIS_CCF_method1_array= [];
for i = 1:350
    im = imread(['E:\BaiduNetdiskDownload\UIE\Dataset-CUIS\CUIS-2\CUIS-2\fusion-based-1\',num2str(i),'.png']);
    quality = CCF(im);
    CUIS_CCF_method1_array = [CUIS_CCF_method1_array,quality];
    fprintf('end %d\n',i);
end

disp(mean(CUIS_CCF_method1_array));
save('CUIS_CCF_method1_array','CUIS_CCF_method1_array');

