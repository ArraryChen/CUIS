clc,clear;

addpath('E:\BaiduNetdiskDownload\CFF_rationality_analysis\CFF_rationality_analysis\tools\CCF');
load('CUIS_CCF_row_array.mat');

% % kmean聚类分析
% [labels, centers] = kmeans_1d(CUIS_CCF_row_array);

% %层次聚类
% [labels, centers] = hierarchical_clustering_1d(CUIS_CCF_row_array);

%高斯混合模型聚类
[labels, centers] = gmm_1d(CUIS_CCF_row_array);

%密度峰�?聚类
% [labels, centers] = density_peak_1d(CUIS_CCF_row_array);



% 显示聚类中心
fprintf('聚类中心: %.4f, %.4f, %.4f\n', centers);

% 统计各聚类的数据点数�?
fprintf('聚类1数量: %d\n', sum(labels == 1));
fprintf('聚类2数量: %d\n', sum(labels == 2));
fprintf('聚类3数量: %d\n', sum(labels == 3));