addpath('F:\image_enhancement\CFF_rationality_analysis\tools\CCF');
%F:\image_enhancement\UIE\Dataset-CUIS\CUIS-1\Water-Net
CUIS_CCF_method7_array= [];
for i = 1:350
    im = imread(['E:\BaiduNetdiskDownload\UIE\Dataset-CUIS\CUIS-1\CUIS-1\Water-Net\',num2str(i),'.png']);
    quality = CCF(im);
    CUIS_CCF_method7_array = [CUIS_CCF_method7_array,quality];
    fprintf('end %d\n',i);
end

disp(mean(CUIS_CCF_method7_array));
save('CUIS_CCF_method7_array','CUIS_CCF_method7_array');

