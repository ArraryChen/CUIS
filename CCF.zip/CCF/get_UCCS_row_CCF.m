clc,clear all;

addpath('E:\BaiduNetdiskDownload\CFF_rationality_analysis\CFF_rationality_analysis\tools\CCF');

UCCS_bg_CCF_row_array= [];
for j = 1:100
    if j-1<10
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','bg_','0',num2str(j-1),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','bg_',num2str(j-1),'.jpg'];
    end

    im = imread(im_name);
    quality = CCF(im);
    UCCS_bg_CCF_row_array = [UCCS_bg_CCF_row_array,quality];
    fprintf('end %d\n',j);
end

UCCS_blue_CCF_row_array= [];
for j = 1:100
    if j-1<10
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','blue_','0',num2str(j-1),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','blue_',num2str(j-1),'.jpg'];
    end

    im = imread(im_name);
    quality = CCF(im);
    UCCS_blue_CCF_row_array = [UCCS_blue_CCF_row_array,quality];
    fprintf('end %d\n',j);
end

UCCS_green_CCF_row_array= [];
for j = 1:100
    if j-1<10
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','green_','0',num2str(j-1),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','green_',num2str(j-1),'.jpg'];
    end

    im = imread(im_name);
    quality = CCF(im);
    UCCS_green_CCF_row_array = [UCCS_green_CCF_row_array,quality];
    fprintf('end %d\n',j);
end







save('UCCS_CCF_row_array','UCCS_bg_CCF_row_array','UCCS_blue_CCF_row_array','UCCS_green_CCF_row_array');

