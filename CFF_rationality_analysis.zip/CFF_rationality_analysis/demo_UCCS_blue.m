clc,clear all;

addpath('F:\image_enhancement\CFF_rationality_analysis\CCF');
addpath('F:\image_enhancement\CFF_rationality_analysis\FDUM');
addpath('F:\image_enhancement\CFF_rationality_analysis\UCIQE');
addpath('F:\image_enhancement\CFF_rationality_analysis\UIQM');
addpath('F:\image_enhancement\CFF_rationality_analysis\NUIQ\NUIQ_Metric');
addpath('F:\image_enhancement\CFF_rationality_analysis\RIR');



load('UCCS_CCF_row_array.mat');
load('UCCS_FDUM_row_array.mat');
load('UCCS_NUIQ_row_array.mat');
load('UCCS_UCIQE_row_array.mat');
load('UCCS_blue_UIQM_row_array.mat');
load('UCCS_blue_UICM_row_array.mat');
load('UCCS_blue_UISM_row_array.mat');
load('UCCS_blue_UIConM_row_array.mat');

load('UCCS_blue_enhance_data.mat');


row_score = UCCS_blue_CCF_row_array;
score = UCCS_blue_enhance_data(:,6);
all_data_changed_rel = [];


row_data = mean(row_score);
data_changed_rel = [];
for i=1:11
    data_changed_rel = [data_changed_rel,(nanmean(score(i,:))-row_data)/row_data];
end

all_data_changed_rel = [all_data_changed_rel;data_changed_rel];


row_score = UCCS_blue_FDUM_row_array;
score = UCCS_blue_enhance_data(:,8);

row_data = mean(row_score);
data_changed_rel = [];
for i=1:11
    data_changed_rel = [data_changed_rel,(nanmean(score(i,:))-row_data)/row_data];
end

all_data_changed_rel = [all_data_changed_rel;data_changed_rel];

row_score = UCCS_blue_UCIQE_row_array;
score = UCCS_blue_enhance_data(:,2);

row_data = mean(row_score);
data_changed_rel = [];
for i=1:11
    data_changed_rel = [data_changed_rel,(nanmean(score(i,:))-row_data)/row_data];
end

all_data_changed_rel = [all_data_changed_rel;data_changed_rel];




row_score = UCCS_blue_NUIQ_row_array;
score = UCCS_blue_enhance_data(:,7);

row_data = mean(row_score);
data_changed_rel = [];
for i=1:11
    data_changed_rel = [data_changed_rel,(nanmean(score(i,:))-row_data)/row_data];
end

all_data_changed_rel = [all_data_changed_rel;data_changed_rel];


row_score = UCCS_blue_UIQM_row_array;
score = UCCS_blue_enhance_data(:,1);

row_data = mean(row_score);
data_changed_rel = [];
for i=1:11
    data_changed_rel = [data_changed_rel,(nanmean(score(i,:))-row_data)/row_data];
end

all_data_changed_rel = [all_data_changed_rel;data_changed_rel];

row_score = UCCS_blue_UICM_row_array;
score = UCCS_blue_enhance_data(:,3);

row_data = mean(row_score);
data_changed_rel = [];
for i=1:11
    data_changed_rel = [data_changed_rel,(nanmean(score(i,:))-row_data)/row_data];
end

all_data_changed_rel = [all_data_changed_rel;data_changed_rel];

row_score = UCCS_blue_UIConM_row_array;
score = UCCS_blue_enhance_data(:,4);

row_data = mean(row_score);
data_changed_rel = [];
for i=1:11
    data_changed_rel = [data_changed_rel,(nanmean(score(i,:))-row_data)/row_data];
end

all_data_changed_rel = [all_data_changed_rel;data_changed_rel];

row_score = UCCS_blue_UISM_row_array;
score = UCCS_blue_enhance_data(:,5);

row_data = mean(row_score);
data_changed_rel = [];
for i=1:11
    data_changed_rel = [data_changed_rel,(nanmean(score(i,:))-row_data)/row_data];
end

all_data_changed_rel = [all_data_changed_rel;data_changed_rel];



changed_data_head={'Ancuti et al.[18]','Ancuti et al.[19]','RGHS [20]','ULAP[23]','Chen et al.[24]',' IBLA[25]','Water-Net [7]','FUnIE-GAN[28]',...
    'U-Former[29]','SC-Net[35]','Shallow-Net [37]'
    };

x = categorical(cellstr(changed_data_head), cellstr(changed_data_head));

y3 = [
    all_data_changed_rel(1, :);
    all_data_changed_rel(2, :);
    all_data_changed_rel(3, :);
    all_data_changed_rel(4, :);
    all_data_changed_rel(5, :);
    all_data_changed_rel(6, :);
    all_data_changed_rel(7, :);
    all_data_changed_rel(8, :);
    ];

figure(3)

b = bar(x,y3, 'grouped');

set(b(1), 'FaceColor', [0.0, 0.45, 0.74]);   % 深蓝色（原颜色1）
set(b(2), 'FaceColor', [0.85, 0.33, 0.10]);  % 橙红色（原颜色2）
set(b(3), 'FaceColor', [0.13, 0.67, 0.25]);  % 深绿色（原颜色3）
set(b(4), 'FaceColor', [0.93, 0.69, 0.13]);  % 金黄色（原颜色4）
set(b(5), 'FaceColor', [0.55, 0.27, 0.56]);  % 深紫色（新增）
set(b(6), 'FaceColor', [0.49, 0.46, 0.37]);  % 灰褐色（新增）
set(b(7), 'FaceColor', [0.64, 0.16, 0.16]);  % 深红色（新增）
set(b(8), 'FaceColor', [0.2, 0.63, 0.79]);   % 天蓝色（新增）


% 设置坐标轴标签和标题
xlabel('UIE methods', 'FontSize', 18);
ylabel('Relative Improvement Rate', 'FontSize', 18);
title('UCCS-BLUE dataset', 'FontSize', 18);
set(gca, 'FontSize', 18);  
% 添加图例
% legend('CCF', 'FDUM', 'UCIQE', 'NUIQ','UIQM', 'UICM', 'UIConM', 'UISM','Location', 'northeast','FontSize', 18,'Title','hhh');
lgd = legend('CCF', 'FDUM', 'UCIQE', 'NUIQ', 'UIQM', 'UICM', 'UIConM', 'UISM', ...
    'Location', 'northeast', 'FontSize', 18);

title(lgd, 'Image Quality Metric', 'FontWeight', 'normal'); 
% 让横坐标标签旋转一定角度，避免重叠，可根据实际情况调整角度
xtickangle(45);


