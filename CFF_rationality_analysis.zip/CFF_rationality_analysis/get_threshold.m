clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\CCF');


list_max_min = [];

load("CCF_slight_scorce.mat");
list_max_min = [list_max_min;[max(CFF_array),min(CFF_array)]];

load("CCF_general_scorce.mat");
list_max_min = [list_max_min;[max(CFF_array),min(CFF_array)]];

load("CCF_severe_scorce.mat");
list_max_min = [list_max_min;[max(CFF_array),min(CFF_array)]];
