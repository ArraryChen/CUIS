clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\CCF');
addpath('F:\image_enhancement\CFF_rationality_analysis\FDUM');
addpath('F:\image_enhancement\CFF_rationality_analysis\UCIQE');
addpath('F:\image_enhancement\CFF_rationality_analysis\UIQM');
addpath('F:\image_enhancement\CFF_rationality_analysis\NUIQ\NUIQ_Metric');


load('CUIS_CCF_method1_array.mat');
load('CUIS_CCF_method2_array.mat');
load('CUIS_CCF_method3_array.mat');
load('CUIS_CCF_method4_array.mat');
load('CUIS_CCF_method5_array.mat');
load('CUIS_CCF_method6_array.mat');
load('CUIS_CCF_method7_array.mat');
load('CUIS_CCF_method8_array.mat');
load('CUIS_CCF_method9_array.mat');
load('CUIS_CCF_method10_array.mat');
load('CUIS_CCF_method11_array.mat');


CUIS_CCF_array = [
    CUIS_CCF_method1_array;
    CUIS_CCF_method2_array;
    CUIS_CCF_method3_array;
    CUIS_CCF_method4_array;
    CUIS_CCF_method5_array;
    CUIS_CCF_method6_array;
    CUIS_CCF_method7_array;
    CUIS_CCF_method8_array;
    CUIS_CCF_method9_array;
    CUIS_CCF_method10_array;
    CUIS_CCF_method11_array;
];
load('CUIS_FDUM_array.mat');
load('CUIS_UCIQE_array.mat');
load('CUIS_UIQM_array.mat');
load('CUIS_UICM_array.mat');
load('CUIS_UIConM_array.mat');
load('CUIS_UISM_array.mat');
load('CUIS_NUIQ_array.mat');


image_num = 1000;
division_datio = [7,9,4];
temp_sum = sum(division_datio);
slight_num = image_num*division_datio(1)/temp_sum;
general_num = image_num*division_datio(2)/temp_sum;
severe_num = image_num*division_datio(3)/temp_sum;


a1 = nanmean(CUIS_UIQM_array(:,1:slight_num),2);
a2 = nanmean(CUIS_UCIQE_array(:,1:slight_num),2);
a3 = nanmean(CUIS_UICM_array(:,1:slight_num),2);
a4 = nanmean(CUIS_UIConM_array(:,1:slight_num),2);
a5 = nanmean(CUIS_UISM_array(:,1:slight_num),2);
a6 = nanmean(CUIS_CCF_array(:,1:slight_num),2);
a7 = nanmean(CUIS_NUIQ_array(:,1:slight_num),2);
a8 = nanmean(CUIS_FDUM_array(:,1:slight_num),2);


slight_table = [a1,a2,a3,a4,a5,a6,a7,a8];
writematrix(slight_table, 'slight_table.xlsx');


b1 = nanmean(CUIS_UIQM_array(:,slight_num:slight_num+general_num),2);
b2 = nanmean(CUIS_UCIQE_array(:,slight_num:slight_num+general_num),2);
b3 = nanmean(CUIS_UICM_array(:,slight_num:slight_num+general_num),2);
b4 = nanmean(CUIS_UIConM_array(:,slight_num:slight_num+general_num),2);
b5 = nanmean(CUIS_UISM_array(:,slight_num:slight_num+general_num),2);
b6 = nanmean(CUIS_CCF_array(:,slight_num:slight_num+general_num),2);
b7 = nanmean(CUIS_NUIQ_array(:,slight_num:slight_num+general_num),2);
b8 = nanmean(CUIS_FDUM_array(:,slight_num:slight_num+general_num),2);


general_table = [b1,b2,b3,b4,b5,b6,b7,b8];
writematrix(general_table, 'general_table.xlsx');


c1 = nanmean(CUIS_UIQM_array(:,slight_num+general_num:image_num),2);
c2 = nanmean(CUIS_UCIQE_array(:,slight_num+general_num:image_num),2);
c3 = nanmean(CUIS_UICM_array(:,slight_num+general_num:image_num),2);
c4 = nanmean(CUIS_UIConM_array(:,slight_num+general_num:image_num),2);
c5 = nanmean(CUIS_UISM_array(:,slight_num+general_num:image_num),2);
c6 = nanmean(CUIS_CCF_array(:,slight_num+general_num:image_num),2);
c7 = nanmean(CUIS_NUIQ_array(:,slight_num+general_num:image_num),2);
c8 = nanmean(CUIS_FDUM_array(:,slight_num+general_num:image_num),2);

% temp = CUIS_UIQM_array(:,slight_num+general_num:image_num);
% temp(isnan(temp)) = 0;  % 将NaN替换为0
% c1 = mean(temp, 2);     % 计算均值
% 
% temp = CUIS_UCIQE_array(:,slight_num+general_num:image_num);
% temp(isnan(temp)) = 0;
% c2 = mean(temp, 2);
% 
% temp = CUIS_UICM_array(:,slight_num+general_num:image_num);
% temp(isnan(temp)) = 0;
% c3 = mean(temp, 2);
% 
% temp = CUIS_UIConM_array(:,slight_num+general_num:image_num);
% temp(isnan(temp)) = 0;
% c4 = mean(temp, 2);
% 
% temp = CUIS_UISM_array(:,slight_num+general_num:image_num);
% temp(isnan(temp)) = 0;
% c5 = mean(temp, 2);
% 
% temp = CUIS_CCF_array(:,slight_num+general_num:image_num);
% temp(isnan(temp)) = 0;
% c6 = mean(temp, 2);
% 
% temp = CUIS_NUIQ_array(:,slight_num+general_num:image_num);
% temp(isnan(temp)) = 0;
% c7 = mean(temp, 2);
% 
% temp = CUIS_FDUM_array(:,slight_num+general_num:image_num);
% temp(isnan(temp)) = 0;
% c8 = mean(temp, 2);


severe_table = [c1,c2,c3,c4,c5,c6,c7,c8];
writematrix(severe_table, 'severe_table.xlsx');


save('slight_table','slight_table');
save('general_table','general_table');
save('severe_table','severe_table');






