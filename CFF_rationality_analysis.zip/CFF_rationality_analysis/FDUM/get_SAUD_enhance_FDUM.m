clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\FDUM\Code-for-FDUM-method\Code');
load("path_data.mat");
Coe=[0.2982    0.4439    0.028];

SAUD_FDUM_array= [];
for i = 1:11
    for j = 1:100
        im = imread([SAUD_path_data{i},num2str(j),'.png']);
        Color = Colorfulness(im);
        Con = Contrast(im);
        Sharp = UIQMSharpness(im);
        quality = Coe(1)*Color+Coe(2)*Con+Coe(3)*Sharp;
        SAUD_FDUM_array (i,j) = quality;
        fprintf('end %d:%d\n',i,j);
    end
end
save('CUIS_SAUD_array','SAUD_FDUM_array');

