clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\FDUM\Code-for-FDUM-method\Code');
load("path_data.mat");
Coe=[0.2982    0.4439    0.028];


UCCS_bg_FDUM_row_array= [];



for j = 1:100
    if j-1<10
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','bg_','0',num2str(j-1),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','bg_',num2str(j-1),'.jpg'];
    end

    im = imread(im_name);
    Color = Colorfulness(im);
    Con = Contrast(im);
    Sharp = UIQMSharpness(im);
    quality = Coe(1)*Color+Coe(2)*Con+Coe(3)*Sharp;
    UCCS_bg_FDUM_row_array (j) = quality;
    fprintf('end %d\n',j);
end


UCCS_blue_FDUM_row_array= [];



for j = 1:100
    if j-1<10
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','blue_','0',num2str(j-1),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','blue_',num2str(j-1),'.jpg'];
    end

    im = imread(im_name);
    Color = Colorfulness(im);
    Con = Contrast(im);
    Sharp = UIQMSharpness(im);
    quality = Coe(1)*Color+Coe(2)*Con+Coe(3)*Sharp;
    UCCS_blue_FDUM_row_array (j) = quality;
    fprintf('end %d\n',j);
end


UCCS_green_FDUM_row_array= [];


for j = 1:100
    if j-1<10
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','green_','0',num2str(j-1),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','green_',num2str(j-1),'.jpg'];
    end

    im = imread(im_name);
    Color = Colorfulness(im);
    Con = Contrast(im);
    Sharp = UIQMSharpness(im);
    quality = Coe(1)*Color+Coe(2)*Con+Coe(3)*Sharp;
    UCCS_green_FDUM_row_array (j) = quality;
    fprintf('end %d\n',j);
end



save('UCCS_FDUM_row_array','UCCS_bg_FDUM_row_array','UCCS_blue_FDUM_row_array','UCCS_green_FDUM_row_array');