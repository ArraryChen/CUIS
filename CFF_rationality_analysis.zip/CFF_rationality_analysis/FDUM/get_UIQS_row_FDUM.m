clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\FDUM\Code-for-FDUM-method\Code');
load("path_data.mat");
Coe=[0.2982    0.4439    0.028];

UIQS_FDUM_row_array= [];
groups = 1;
numbers_in_each_group = 726;


for j = 1:726
    if (0<j) && (j<10)
        im_name = ['F:\image_enhancement\UIE\Dataset-UIQS\before\','C_','00',num2str(j),'.jpg'];
    elseif (9<j) && (j<100)
        im_name = ['F:\image_enhancement\UIE\Dataset-UIQS\before\','C_','0',num2str(j),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UIQS\before\','C_',num2str(j),'.jpg'];
    end

    im = imread(im_name);
    Color = Colorfulness(im);
    Con = Contrast(im);
    Sharp = UIQMSharpness(im);
    quality = Coe(1)*Color+Coe(2)*Con+Coe(3)*Sharp;
    UIQS_FDUM_row_array (j) = quality;
    fprintf('end %d\n',j);
end


save('UIQS_FDUM_row_array',"UIQS_FDUM_row_array");