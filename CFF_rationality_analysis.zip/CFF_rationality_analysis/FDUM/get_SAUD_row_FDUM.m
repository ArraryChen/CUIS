clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\FDUM\Code-for-FDUM-method\Code');
Coe=[0.2982    0.4439    0.028];

SAUD_FDUM_row_array= [];
for i = 1:100
    im = imread(['F:\image_enhancement\SAUD-NUIQ\',num2str(i),'.png']);
    Color = Colorfulness(im);
    Con = Contrast(im);
    Sharp = UIQMSharpness(im);
    quality = Coe(1)*Color+Coe(2)*Con+Coe(3)*Sharp;
    SAUD_FDUM_row_array = [SAUD_FDUM_row_array,quality];
    fprintf('end %d\n',i);
end


disp(mean(SAUD_FDUM_row_array));
save('SAUD_FDUM_row_array','SAUD_FDUM_row_array');

