clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\FDUM\Code-for-FDUM-method\Code');
Coe=[0.2982    0.4439    0.028];

CUIS_FDUM_row_array= [];
for i = 1:200
    im = imread(['F:\image_enhancement\CUIS-raw\CUIS-slight\',num2str(i),'.png']);
    Color = Colorfulness(im);
    Con = Contrast(im);
    Sharp = UIQMSharpness(im);
    quality = Coe(1)*Color+Coe(2)*Con+Coe(3)*Sharp;
    CUIS_FDUM_row_array = [CUIS_FDUM_row_array,quality];
    fprintf('end %d\n',i);
end


for i = 201:800
    im = imread(['F:\image_enhancement\CUIS-raw\CUIS-general\',num2str(i),'.png']);
    Color = Colorfulness(im);
    Con = Contrast(im);
    Sharp = UIQMSharpness(im);
    quality = Coe(1)*Color+Coe(2)*Con+Coe(3)*Sharp;
    CUIS_FDUM_row_array = [CUIS_FDUM_row_array,quality];
    fprintf('end %d\n',i);
end


for i = 801:1000
    im = imread(['F:\image_enhancement\CUIS-raw\CUIS-severe\',num2str(i),'.png']);
    Color = Colorfulness(im);
    Con = Contrast(im);
    Sharp = UIQMSharpness(im);
    quality = Coe(1)*Color+Coe(2)*Con+Coe(3)*Sharp;
    CUIS_FDUM_row_array = [CUIS_FDUM_row_array,quality];
    fprintf('end %d\n',i);
end

disp(mean(CUIS_FDUM_row_array));
save('CUIS_FDUM_row_array','CUIS_FDUM_row_array');

