get_SAUD_row_FDUM;
get_SAUD_enhance_FDUM;
clc,clear;

load('SAUD_FDUM_row_array.mat');
load('SAUD_FDUM_array.mat');

row_data = mean(SAUD_FDUM_row_array);
data_changed_abs = [];
data_changed_rel = [];
data_abs = [];
for i=1:11
    data_abs = [data_abs,nanmean(SAUD_FDUM_array(i,:))];
    data_changed_abs = [data_changed_abs,nanmean(SAUD_FDUM_array(i,:))-row_data];
    data_changed_rel = [data_changed_rel,(nanmean(SAUD_FDUM_array(i,:))-row_data)/row_data];
end

all_data = [SAUD_FDUM_row_array;SAUD_FDUM_array];

data_head={'row';'method1';'method2';'method3';'method4';'method5';'method6';'method7';'method8';...
    'method9';'method10';'method11'
    };
all_data_dir = [data_head,num2cell(all_data)];

changed_data_head={'method1','method2','method3','method4','method5','method6','method7','method8',...
    'method9','method10','method11'
    };
changed_FDUM_SAUD_data_dir = [changed_data_head;num2cell(data_abs);num2cell(data_changed_abs);num2cell(data_changed_rel)];

save('changed_FDUM_SAUD_data_dir','changed_FDUM_SAUD_data_dir');

