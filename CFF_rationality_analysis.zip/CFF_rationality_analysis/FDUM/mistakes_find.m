clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\FDUM\Code-for-FDUM-method\Code');
load("path_data.mat");
Coe=[0.2982    0.4439    0.028];


im = imread([path_data{1},num2str(663),'.png']);
Color = Colorfulness(im);
Con = Contrast(im);
Sharp = UIQMSharpness(im);
quality = Coe(1)*Color+Coe(2)*Con+Coe(3)*Sharp



