clc,clear;
path_data = {
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-2\fusion-based-1\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-2\fusion-based-2\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-2\RGHS\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-3\ULAP\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-3\Chen\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-3\IBLA\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-1\Water-Net\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-1\FUnIE-GAN\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-1\U-Former\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-1\SCNet\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-1\Shallow-Net\';
};

SAUD_path_data = {
    'F:\image_enhancement\UIE\Dataset-SAUD\dataforSAUD\1.fusion-based-1-forSAUD\';
    'F:\image_enhancement\UIE\Dataset-SAUD\dataforSAUD\2.fusion-based-2-forSAUD\';
    'F:\image_enhancement\UIE\Dataset-SAUD\dataforSAUD\3.RGHS-forSAUD\';
    'F:\image_enhancement\UIE\Dataset-SAUD\dataforSAUD\4.ULAP-forSAUD\';
    'F:\image_enhancement\UIE\Dataset-SAUD\dataforSAUD\5.Chen-forSAUD\';
    'F:\image_enhancement\UIE\Dataset-SAUD\dataforSAUD\6.IBLA-forSAUD\';
    'F:\image_enhancement\UIE\Dataset-SAUD\dataforSAUD\7.Water-Net-forSAUD\';
    'F:\image_enhancement\UIE\Dataset-SAUD\dataforSAUD\8.FUnIE-GAN-forSAUD\';
    'F:\image_enhancement\UIE\Dataset-SAUD\dataforSAUD\9.U-Former-forSAUD\';
    'F:\image_enhancement\UIE\Dataset-SAUD\dataforSAUD\10.SC-Net-forSAUD\';
    'F:\image_enhancement\UIE\Dataset-SAUD\dataforSAUD\11.Shallow-Net-forSAUD\';
    };

UIEB_path_data = {
    'F:\image_enhancement\UIE\Dataset-UIEB\ZZZ-Fusion1\';
    'F:\image_enhancement\UIE\Dataset-UIEB\ZZZ-Fusion2\';
    'F:\image_enhancement\UIE\Dataset-UIEB\ZZZ-RGHS\';
    'F:\image_enhancement\UIE\Dataset-UIEB\ZZZ-ULAP\';
    'F:\image_enhancement\UIE\Dataset-UIEB\ZZZ-Chen\';
    'F:\image_enhancement\UIE\Dataset-UIEB\ZZZ-IBLA\';
    'F:\image_enhancement\UIE\Dataset-UIEB\ZZZ-WaterNet\';
    'F:\image_enhancement\UIE\Dataset-UIEB\ZZZ-FUnIE-GAN\';
    'F:\image_enhancement\UIE\Dataset-UIEB\ZZZ-Uformer\';
    'F:\image_enhancement\UIE\Dataset-UIEB\ZZZ-SC-Net\';
    'F:\image_enhancement\UIE\Dataset-UIEB\ZZZ-Shallow\';
    };

UIQS_path_data = {
    'F:\image_enhancement\UIE\Dataset-UIQS\QQQ-Fusion1\after\';
    'F:\image_enhancement\UIE\Dataset-UIQS\QQQ-Fusion2\after\';
    'F:\image_enhancement\UIE\Dataset-UIQS\QQQ-RGHS\after\';
    'F:\image_enhancement\UIE\Dataset-UIQS\QQQ-ULAP\after\';
    'F:\image_enhancement\UIE\Dataset-UIQS\QQQ-Chen\after\';
    'F:\image_enhancement\UIE\Dataset-UIQS\QQQ-IBLA\after\';
    'F:\image_enhancement\UIE\Dataset-UIQS\QQQ-WaterNet\after\';
    'F:\image_enhancement\UIE\Dataset-UIQS\QQQ-FUnIE-GAN\after\';
    'F:\image_enhancement\UIE\Dataset-UIQS\QQQ-Uformer\after\';
    'F:\image_enhancement\UIE\Dataset-UIQS\QQQ-SC-Net\after\';
    'F:\image_enhancement\UIE\Dataset-UIQS\QQQ-Shallow\after\';
    };

UCCS_path_data = {
    'F:\image_enhancement\UIE\Dataset-UCCS\CCC-Fusion1\after\';
    'F:\image_enhancement\UIE\Dataset-UCCS\CCC-Fusion2\after\';
    'F:\image_enhancement\UIE\Dataset-UCCS\CCC-RGHS\after\';
    'F:\image_enhancement\UIE\Dataset-UCCS\CCC-ULAP\after\';
    'F:\image_enhancement\UIE\Dataset-UCCS\CCC-Chen\after\';
    'F:\image_enhancement\UIE\Dataset-UCCS\CCC-IBLA\after\';
    'F:\image_enhancement\UIE\Dataset-UCCS\CCC-WaterNet\after\';
    'F:\image_enhancement\UIE\Dataset-UCCS\CCC-FUnIE-GAN\after\';
    'F:\image_enhancement\UIE\Dataset-UCCS\CCC-Uformer\after\';
    'F:\image_enhancement\UIE\Dataset-UCCS\CCC-SC-Net\after\';
    'F:\image_enhancement\UIE\Dataset-UCCS\CCC-Shallow\after\';
    };


save("path_data");