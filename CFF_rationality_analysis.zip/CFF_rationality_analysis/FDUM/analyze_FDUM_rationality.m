% get_CUIS_row_FDUM;
% get_CUIS_enhance_FDUM;
clc,clear;

load('CUIS_FDUM_row_array.mat');
load('CUIS_FDUM_array.mat');

row_data = mean(CUIS_FDUM_row_array);
data_changed_abs = [];
data_changed_rel = [];
data_abs = [];
for i=1:11
    data_abs = [data_abs,nanmean(CUIS_FDUM_array(i,:))];
    data_changed_abs = [data_changed_abs,nanmean(CUIS_FDUM_array(i,:))-row_data];
    data_changed_rel = [data_changed_rel,(nanmean(CUIS_FDUM_array(i,:))-row_data)/row_data];
end

all_data = [CUIS_FDUM_row_array;CUIS_FDUM_array];

data_head={'row';'method1';'method2';'method3';'method4';'method5';'method6';'method7';'method8';...
    'method9';'method10';'method11'
    };
all_data_dir = [data_head,num2cell(all_data)];

changed_data_head={'method1','method2','method3','method4','method5','method6','method7','method8',...
    'method9','method10','method11'
    };
changed_FDUM_data_dir = [changed_data_head;num2cell(data_abs);num2cell(data_changed_abs);num2cell(data_changed_rel)];

save('changed_FDUM_data_dir','changed_FDUM_data_dir');

