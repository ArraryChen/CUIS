clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\FDUM\Code-for-FDUM-method\Code');
load("path_data.mat");
Coe=[0.2982    0.4439    0.028];

UIEB_FDUM_row_array= [];
groups = 1;
numbers_in_each_group = 950;


for j = 1:950
    im = imread(['F:\image_enhancement\UIE\Dataset-UIEB\before\',num2str(j),'.png']);
    Color = Colorfulness(im);
    Con = Contrast(im);
    Sharp = UIQMSharpness(im);
    quality = Coe(1)*Color+Coe(2)*Con+Coe(3)*Sharp;
    UIEB_FDUM_row_array (j) = quality;
    fprintf('end %d\n',j);
end


save('UIEB_FDUM_row_array',"UIEB_FDUM_row_array");