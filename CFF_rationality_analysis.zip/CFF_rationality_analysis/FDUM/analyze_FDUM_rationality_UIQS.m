get_UIQS_row_FDUM;
get_UIQS_enhance_FDUM;
clc,clear;

load('UIQS_FDUM_row_array.mat');
load('UIQS_FDUM_array.mat');

row_data = mean(UIQS_FDUM_row_array);
data_changed_abs = [];
data_changed_rel = [];
data_abs = [];
for i=1:11
    data_abs = [data_abs,nanmean(UIQS_FDUM_array(i,:))];
    data_changed_abs = [data_changed_abs,nanmean(UIQS_FDUM_array(i,:))-row_data];
    data_changed_rel = [data_changed_rel,(nanmean(UIQS_FDUM_array(i,:))-row_data)/row_data];
end

all_data = [UIQS_FDUM_row_array;UIQS_FDUM_array];

data_head={'row';'method1';'method2';'method3';'method4';'method5';'method6';'method7';'method8';...
    'method9';'method10';'method11'
    };
all_data_dir = [data_head,num2cell(all_data)];

changed_data_head={'method1','method2','method3','method4','method5','method6','method7','method8',...
    'method9','method10','method11'
    };
changed_FDUM_UIQS_data_dir = [changed_data_head;num2cell(data_abs);num2cell(data_changed_abs);num2cell(data_changed_rel)];

save('changed_FDUM_UIQS_data_dir','changed_FDUM_UIQS_data_dir');

