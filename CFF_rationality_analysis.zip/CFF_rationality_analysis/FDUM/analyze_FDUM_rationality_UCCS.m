get_UCCS_row_FDUM;
get_UCCS_enhance_FDUM;
clc,clear;

load('UCCS_FDUM_row_array.mat');
load('UCCS_FDUM_array.mat');

bg_row_data = mean(UCCS_bg_FDUM_row_array);
bg_data_changed_abs = [];
bg_data_changed_rel = [];
bg_data_abs = [];

blue_row_data = mean(UCCS_blue_FDUM_row_array);
blue_data_changed_abs = [];
blue_data_changed_rel = [];
blue_data_abs = [];

green_row_data = mean(UCCS_green_FDUM_row_array);
green_data_changed_abs = [];
green_data_changed_rel = [];
green_data_abs = [];



for i=1:11
    bg_data_abs = [bg_data_abs,nanmean(UCCS_bg_FDUM_array(i,:))];
    bg_data_changed_abs = [bg_data_changed_abs,nanmean(UCCS_bg_FDUM_array(i,:))-bg_row_data];
    bg_data_changed_rel = [bg_data_changed_rel,(nanmean(UCCS_bg_FDUM_array(i,:))-bg_row_data)/bg_row_data];
end

for i=1:11
    blue_data_abs = [blue_data_abs,nanmean(UCCS_blue_FDUM_array(i,:))];
    blue_data_changed_abs = [blue_data_changed_abs,nanmean(UCCS_blue_FDUM_array(i,:))-blue_row_data];
    blue_data_changed_rel = [blue_data_changed_rel,(nanmean(UCCS_blue_FDUM_array(i,:))-blue_row_data)/blue_row_data];
end

for i=1:11
    green_data_abs = [green_data_abs,nanmean(UCCS_green_FDUM_array(i,:))];
    green_data_changed_abs = [green_data_changed_abs,nanmean(UCCS_green_FDUM_array(i,:))-green_row_data];
    green_data_changed_rel = [green_data_changed_rel,(nanmean(UCCS_green_FDUM_array(i,:))-green_row_data)/green_row_data];
end


data_head={'row';'method1';'method2';'method3';'method4';'method5';'method6';'method7';'method8';...
    'method9';'method10';'method11'
    };


bg_all_data = [UCCS_bg_FDUM_row_array;UCCS_bg_FDUM_array];
blue_all_data = [UCCS_blue_FDUM_row_array;UCCS_blue_FDUM_array];
green_all_data = [UCCS_green_FDUM_row_array;UCCS_green_FDUM_array];


bg_all_data_dir = [data_head,num2cell(bg_all_data)];
blue_all_data_dir = [data_head,num2cell(blue_all_data)];
green_all_data_dir = [data_head,num2cell(green_all_data)];


changed_data_head={'method1','method2','method3','method4','method5','method6','method7','method8',...
    'method9','method10','method11'
    };


changed_FDUM_UCCS_bg_data_dir = [changed_data_head;num2cell(bg_data_abs);num2cell(bg_data_changed_abs);num2cell(bg_data_changed_rel)];
changed_FDUM_UCCS_blue_data_dir = [changed_data_head;num2cell(blue_data_abs);num2cell(blue_data_changed_abs);num2cell(blue_data_changed_rel)];
changed_FDUM_UCCS_green_data_dir = [changed_data_head;num2cell(green_data_abs);num2cell(green_data_changed_abs);num2cell(green_data_changed_rel)];


save('changed_FDUM_UIQS_data_dir','changed_FDUM_UCCS_bg_data_dir','changed_FDUM_UCCS_blue_data_dir','changed_FDUM_UCCS_green_data_dir');

