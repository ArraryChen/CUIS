clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\UCIQE');
load("path_data.mat");

UIQS_UCIQE_array= [];
for i = 1:11
    for j = 1:726
        if (0<j) && (j<10)
            im_name = [UIQS_path_data{i},'C_','00',num2str(j),'.jpg'];
        elseif (9<j) && (j<100)
            im_name = [UIQS_path_data{i},'C_','0',num2str(j),'.jpg'];
        else
            im_name = [UIQS_path_data{i},'C_',num2str(j),'.jpg'];
        end

        im = imread(im_name);
        quality = UCIQE(im);
        UIQS_UCIQE_array(i,j) = quality;
        fprintf('end %d:%d\n',i,j);
    end
end
save('UIQS_UCIQE_array','UIQS_UCIQE_array');

