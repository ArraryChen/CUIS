clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\UCIQE');
load("path_data.mat");

UIEB_UCIQE_array= [];


for i = 1:11
    for j = 1:950
        im = imread([UIEB_path_data{i},'after\',num2str(j),'.png']);
        quality = UCIQE(im);
        UIEB_UCIQE_array(i,j) = quality;
        fprintf('end %d:%d\n',i,j);
    end
end

save('UIEB_UCIQE_array',"UIEB_UCIQE_array");