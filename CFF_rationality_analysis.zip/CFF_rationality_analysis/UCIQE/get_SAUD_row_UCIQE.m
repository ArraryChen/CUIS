clc,clear;


addpath('F:\image_enhancement\CFF_rationality_analysis\tools\UCIQE');
load("path_data.mat");


SAUD_UCIQE_row_array= [];
for i = 1:100
    im = imread(['F:\image_enhancement\SAUD-NUIQ\',num2str(i),'.png']);
    quality = UCIQE(im);
    SAUD_UCIQE_row_array(i) = quality;
    fprintf('end %d\n',i);
end


save('SAUD_UCIQE_row_array','SAUD_UCIQE_row_array');

