clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\UCIQE');
load("path_data.mat");

CUIS_UCIQE_array= [];
for i = 1:11
    for j = 1:1000
        im = imread([path_data{i},num2str(j),'.png']);
        quality = UCIQE(im);
        CUIS_UCIQE_array(i,j) = quality;
        fprintf('end %d:%d\n',i,j);
    end
end
save('CUIS_UCIQE_array','CUIS_UCIQE_array');

