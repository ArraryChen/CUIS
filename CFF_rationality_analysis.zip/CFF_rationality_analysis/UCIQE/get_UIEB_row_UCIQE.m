clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\UCIQE');
load("path_data.mat");

UIEB_UCIQE_row_array= [];
groups = 1;
numbers_in_each_group = 950;


for j = 1:950
    im = imread(['F:\image_enhancement\UIE\Dataset-UIEB\before\',num2str(j),'.png']);
    quality = UCIQE(im);
    UIEB_UCIQE_row_array(j) = quality;
    fprintf('end %d\n',j);
end


save('UIEB_UCIQE_row_array',"UIEB_UCIQE_row_array");