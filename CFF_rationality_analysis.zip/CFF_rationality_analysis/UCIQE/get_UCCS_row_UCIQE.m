clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\UCIQE');
load("path_data.mat");


UCCS_bg_UCIQE_row_array= [];



for j = 1:100
    if j-1<10
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','bg_','0',num2str(j-1),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','bg_',num2str(j-1),'.jpg'];
    end

    im = imread(im_name);
    quality = UCIQE(im);
    UCCS_bg_UCIQE_row_array(j) = quality;
    fprintf('end %d\n',j);
end


UCCS_blue_UCIQE_row_array= [];



for j = 1:100
    if j-1<10
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','blue_','0',num2str(j-1),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','blue_',num2str(j-1),'.jpg'];
    end

    im = imread(im_name);
    quality = UCIQE(im);
    UCCS_blue_UCIQE_row_array(j) = quality;
    fprintf('end %d\n',j);
end


UCCS_green_UCIQE_row_array= [];


for j = 1:100
    if j-1<10
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','green_','0',num2str(j-1),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','green_',num2str(j-1),'.jpg'];
    end

    im = imread(im_name);
    quality = UCIQE(im);
    UCCS_green_UCIQE_row_array(j) = quality;
    fprintf('end %d\n',j);
end



save('UCCS_UCIQE_row_array','UCCS_bg_UCIQE_row_array','UCCS_blue_UCIQE_row_array','UCCS_green_UCIQE_row_array');