clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\UCIQE');


CUIS_UCIQE_row_array= [];
for i = 1:200
    im = imread(['F:\image_enhancement\CUIS-raw\CUIS-slight\',num2str(i),'.png']);
    quality = UCIQE(im);
    CUIS_UCIQE_row_array = [CUIS_UCIQE_row_array,quality];
    fprintf('end %d\n',i);
end


for i = 201:800
    im = imread(['F:\image_enhancement\CUIS-raw\CUIS-general\',num2str(i),'.png']);
    quality = UCIQE(im);
    CUIS_UCIQE_row_array = [CUIS_UCIQE_row_array,quality];
    fprintf('end %d\n',i);
end


for i = 801:1000
    im = imread(['F:\image_enhancement\CUIS-raw\CUIS-severe\',num2str(i),'.png']);
    quality = UCIQE(im);
    CUIS_UCIQE_row_array = [CUIS_UCIQE_row_array,quality];
    fprintf('end %d\n',i);
end

disp(mean(CUIS_UCIQE_row_array));
save('CUIS_UCIQE_row_array','CUIS_UCIQE_row_array');



