clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\UCIQE');
load("path_data.mat");

UIQS_UCIQE_row_array= [];

for j = 1:726
    if (0<j) && (j<10)
        im_name = ['F:\image_enhancement\UIE\Dataset-UIQS\before\','C_','00',num2str(j),'.jpg'];
    elseif (9<j) && (j<100)
        im_name = ['F:\image_enhancement\UIE\Dataset-UIQS\before\','C_','0',num2str(j),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UIQS\before\','C_',num2str(j),'.jpg'];
    end

    im = imread(im_name);
    quality = UCIQE(im);
    UIQS_UCIQE_row_array(j) = quality;
    fprintf('end %d\n',j);
end

save('UIQS_UCIQE_row_array','UIQS_UCIQE_row_array');

