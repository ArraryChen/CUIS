clc,clear all;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\CCF');

SAUD_CCF_row_array= [];
for i = 1:100
    im = imread(['F:\image_enhancement\SAUD-NUIQ\',num2str(i),'.png']);
    quality = CCF(im);
    SAUD_CCF_row_array = [SAUD_CCF_row_array,quality];
    fprintf('end %d\n',i);
end


save('SAUD_CCF_row_array','SAUD_CCF_row_array');

