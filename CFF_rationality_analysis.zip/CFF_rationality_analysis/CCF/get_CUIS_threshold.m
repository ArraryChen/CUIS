clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\CCF');
load('CUIS_CCF_row_array.mat');

image_num = 1000;
division_datio = [7,9,4];

temp_sum = sum(division_datio);
slight_num = image_num*division_datio(1)/temp_sum;
general_num = image_num*division_datio(2)/temp_sum;
severe_num = image_num*division_datio(3)/temp_sum;


list_max_min = [];
list_max_min = [list_max_min;[max(CUIS_CCF_row_array(1:slight_num)),min(CUIS_CCF_row_array(1:slight_num))]];
list_max_min = [list_max_min;[max(CUIS_CCF_row_array(slight_num:slight_num+general_num)),min(CUIS_CCF_row_array(slight_num:slight_num+general_num))]];
list_max_min = [list_max_min;[max(CUIS_CCF_row_array(slight_num+general_num:image_num)),min(CUIS_CCF_row_array(slight_num+general_num:image_num))]];


