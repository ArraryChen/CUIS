function [cluster_labels, cluster_centers] = hierarchical_clustering_1d(data)
% 使用层次聚类将1D数据分为三组，返回标签和聚类中心
    data_matrix = data(:);  % 转换为列向量
    Y = pdist(data_matrix);  % 计算距离矩阵
    Z = linkage(Y, 'ward');  % 使用Ward方法进行链接
    cluster_labels = cluster(Z, 3);  % 分为3组
    
    % 计算聚类中心
    cluster_centers = zeros(3, 1);
    for i = 1:3
        cluster_centers(i) = mean(data(cluster_labels == i));
    end
    
    % 可视化结果
    figure;
    hold on;
    colors = lines(3);
    for i = 1:3
        idx = find(cluster_labels == i);
        scatter(idx, data(idx), 20, colors(i,:), 'filled', 'MarkerFaceAlpha', 0.5);
        % 绘制聚类中心
        line([min(idx) max(idx)], [cluster_centers(i) cluster_centers(i)], 'Color', colors(i,:), 'LineWidth', 2);
    end
    title('层次聚类结果');
    xlabel('数据索引');
    ylabel('值');
    legend('聚类1', '聚类2', '聚类3', 'Location', 'best');
    grid on;
end