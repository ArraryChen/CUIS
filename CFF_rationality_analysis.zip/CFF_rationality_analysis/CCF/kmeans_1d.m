function [cluster_labels, cluster_centers] = kmeans_1d(data, k)
% KMEANS_1D - 对1D数据执行K-means聚类
% 输入:
%   data - 1×N的double数组
%   k - 聚类数量(默认=3)
% 输出:
%   cluster_labels - 1×N的标签数组，指示每个数据点的聚类
%   cluster_centers - 1×k的数组，包含各聚类的中心值

% 检查输入参数
if nargin < 2
    k = 3; % 默认分为3组
end

% 重塑数据为N×1的矩阵（kmeans函数要求输入为列向量）
data_matrix = data(:);

% 使用MATLAB内置kmeans函数执行聚类
[cluster_labels, cluster_centers] = kmeans(data_matrix, k,'Distance','cityblock','MaxIter',10000);

% 定义颜色映射
colors = lines(k);

% 可视化聚类结果
figure;
hold on;
% 绘制原始数据点，按聚类着色
for i = 1:k
    cluster_data = data(cluster_labels == i);
    scatter(1:length(cluster_data), cluster_data, 20, colors(i,:), 'filled', 'MarkerFaceAlpha', 0.5);
end
% 绘制聚类中心
plot(1:length(data), cluster_centers(cluster_labels), 'k.', 'MarkerSize', 12);
hold off;
title('K-means Clustering Results (k=3)');
xlabel('Data Index');
ylabel('Value');
legend('Cluster 1', 'Cluster 2', 'Cluster 3', 'Centers', 'Location', 'best');
grid on;
end