% % 生成示例数据
% data = [randn(100,2)*0.75+ones(100,2);
%         randn(100,2)*0.5-ones(100,2);
%         randn(100,2)*0.75+[ones(100,1),-ones(100,1)]];
% 
% % 设置聚类数量
% k = 3;
% 
% % 运行K-means算法
% [idx, centers] = kmeans(data, k);
% 
% % 可视化结果
% figure;
% gscatter(data(:,1), data(:,2), idx, 'rgb', 'osd', 10);
% hold on;
% plot(centers(:,1), centers(:,2), 'kx', 'MarkerSize', 15, 'LineWidth', 3);
% title('K-means Clustering Results');
% xlabel('Feature 1');
% ylabel('Feature 2');
% legend('Cluster 1', 'Cluster 2', 'Cluster 3', 'Centroids', 'Location', 'best');
% hold off;

% 生成示例数据（1×1000的混合高斯分布）
data = [randn(1, 400)*0.5 + 2, randn(1, 300)*0.7 - 1, randn(1, 300)*0.3 + 5];

% 执行聚类
[labels, centers] = kmeans_1d(data);

% 显示聚类中心
fprintf('聚类中心: %.4f, %.4f, %.4f\n', centers);

% 统计各聚类的数据点数量
fprintf('聚类1数量: %d\n', sum(labels == 1));
fprintf('聚类2数量: %d\n', sum(labels == 2));
fprintf('聚类3数量: %d\n', sum(labels == 3));