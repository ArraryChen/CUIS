clc,clear;

% get_CUIS_row_CCF;
% get_CUIS_method1_CCF;
% get_CUIS_method2_CCF;
% get_CUIS_method3_CCF;
% get_CUIS_method4_CCF;
% get_CUIS_method5_CCF;
% get_CUIS_method6_CCF;
% get_CUIS_method7_CCF;
% get_CUIS_method8_CCF;
% get_CUIS_method9_CCF;
% get_CUIS_method10_CCF;
% get_CUIS_method11_CCF;

load('CUIS_CCF_row_array.mat');
load('CUIS_CCF_method1_array.mat');
load('CUIS_CCF_method2_array.mat');
load('CUIS_CCF_method3_array.mat');
load('CUIS_CCF_method4_array.mat');
load('CUIS_CCF_method5_array.mat');
load('CUIS_CCF_method6_array.mat');
load('CUIS_CCF_method7_array.mat');
load('CUIS_CCF_method8_array.mat');
load('CUIS_CCF_method9_array.mat');
load('CUIS_CCF_method10_array.mat');
load('CUIS_CCF_method11_array.mat');

row_data = mean(CUIS_CCF_row_array);
data_abs = [
    mean(CUIS_CCF_method1_array);
    mean(CUIS_CCF_method2_array);
    mean(CUIS_CCF_method3_array);
    mean(CUIS_CCF_method4_array);
    mean(CUIS_CCF_method5_array);
    mean(CUIS_CCF_method6_array);
    mean(CUIS_CCF_method7_array);
    mean(CUIS_CCF_method8_array);
    mean(CUIS_CCF_method9_array);
    mean(CUIS_CCF_method10_array);
    mean(CUIS_CCF_method11_array);
    ];
data_changed_abs = [
    mean(CUIS_CCF_method1_array)-row_data;
    mean(CUIS_CCF_method2_array)-row_data;
    mean(CUIS_CCF_method3_array)-row_data;
    mean(CUIS_CCF_method4_array)-row_data;
    mean(CUIS_CCF_method5_array)-row_data;
    mean(CUIS_CCF_method6_array)-row_data;
    mean(CUIS_CCF_method7_array)-row_data;
    mean(CUIS_CCF_method8_array)-row_data;
    mean(CUIS_CCF_method9_array)-row_data;
    mean(CUIS_CCF_method10_array)-row_data;
    mean(CUIS_CCF_method11_array)-row_data;
    ];
data_changed_rel = [
    (mean(CUIS_CCF_method1_array)-row_data)/row_data;
    (mean(CUIS_CCF_method2_array)-row_data)/row_data;
    (mean(CUIS_CCF_method3_array)-row_data)/row_data;
    (mean(CUIS_CCF_method4_array)-row_data)/row_data;
    (mean(CUIS_CCF_method5_array)-row_data)/row_data;
    (mean(CUIS_CCF_method6_array)-row_data)/row_data;
    (mean(CUIS_CCF_method7_array)-row_data)/row_data;
    (mean(CUIS_CCF_method8_array)-row_data)/row_data;
    (mean(CUIS_CCF_method9_array)-row_data)/row_data;
    (mean(CUIS_CCF_method10_array)-row_data)/row_data;
    (mean(CUIS_CCF_method11_array)-row_data)/row_data;
    ];


changed_data_head={'method1','method2','method3','method4','method5','method6','method7','method8',...
    'method9','method10','method11'
    };
changed_CCF_data_dir = [changed_data_head;num2cell(data_abs');num2cell(data_changed_abs');num2cell(data_changed_rel')];

save('changed_CCF_data_dir','changed_CCF_data_dir');




