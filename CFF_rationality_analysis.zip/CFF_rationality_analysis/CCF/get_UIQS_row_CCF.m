clc,clear all;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\CCF');

UIQS_CCF_row_array= [];
for i = 1:726
    if (0<i) && (i<10)
        im_name = ['F:\image_enhancement\UIE\Dataset-UIQS\before\','C_','00',num2str(i),'.jpg'];
    elseif (9<i) && (i<100)
        im_name = ['F:\image_enhancement\UIE\Dataset-UIQS\before\','C_','0',num2str(i),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UIQS\before\','C_',num2str(i),'.jpg'];
    end

    im = imread(im_name);
    quality = CCF(im);
    UIQS_CCF_row_array = [UIQS_CCF_row_array,quality];
    fprintf('end %d\n',i);
end


save('UIQS_CCF_row_array','UIQS_CCF_row_array');

