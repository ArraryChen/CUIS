clc,clear all;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\CCF');

UIEB_CCF_row_array= [];
for i = 1:950
    im = imread(['F:\image_enhancement\UIE\Dataset-UIEB\before\',num2str(i),'.png']);
    quality = CCF(im);
    UIEB_CCF_row_array = [UIEB_CCF_row_array,quality];
    fprintf('end %d\n',i);
end


save('UIEB_CCF_row_array','UIEB_CCF_row_array');

