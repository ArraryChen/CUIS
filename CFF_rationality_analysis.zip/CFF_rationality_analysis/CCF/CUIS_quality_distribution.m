clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\CCF');
load('CUIS_CCF_row_array.mat');

% 生成示例数据（1x1000的double数组，数值范围1-100）
% data = rand(1, 1000) * 99 + 1; % 生成1-100之间的随机数
data = CUIS_CCF_row_array;

% 定义区间范围（总大小[1,100]，分为10个区间）
edges = linspace(1, 90, 10); % 创建11个边界点（10个区间）

% 计算每个区间的统计数据
counts = histcounts(data, edges); % 统计每个区间的元素数量
centers = (edges(1:end-1) + edges(2:end)) / 2; % 计算每个区间的中心位置

% 创建图形
figure('Position', [100, 100, 800, 500]); % 设置图形窗口位置和大小

% 绘制柱状图
bar(centers, counts, 'FaceColor', [0.4, 0.6, 0.8], 'EdgeColor', 'black');
hold on;

% 添加数据标签
for i = 1:length(counts)
    text(centers(i), counts(i) + max(counts) * 0.02, num2str(counts(i)), ...
        'HorizontalAlignment', 'center', 'FontSize', 10);
end

% 添加统计信息文本框
stats_text = sprintf('Statistics:\nTotal sample size: %d\nMinimun: %.2f\nMaximen: %.2f\nAverage: %.2f\nStandard deviation: %.2f', ...
    length(data), min(data), max(data), mean(data), std(data));
annotation('textbox', [0.7, 0.7, 0.25, 0.25], 'String', stats_text, ...
    'FitBoxToText', 'on', 'BackgroundColor', [0.95, 0.95, 0.95], 'EdgeColor', 'none');

% 设置坐标轴和标题
title('CUIS image Quality', 'FontSize', 14, 'FontWeight', 'bold');
xlabel('Interval', 'FontSize', 12);
ylabel('Image number', 'FontSize', 12);
xticks(centers); % 设置x轴刻度为区间中心
xticklabels({'(1-10]', '(10-20]', '(20-30]', '(30-40]', '(40-50]', ...
             '(50-60]', '(60-70]', '(70-80]', '(80-90]'}); % 设置x轴刻度标签
grid on; % 显示网格线

% 美化图表
set(gca, 'FontSize', 10, 'Box', 'off', 'LineWidth', 1);
set(findall(gcf, 'Type', 'axes'), 'FontName', 'Arial');