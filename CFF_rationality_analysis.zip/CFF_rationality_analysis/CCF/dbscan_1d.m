function [cluster_labels, cluster_centers] = dbscan_1d(data)
% 使用DBSCAN将1D数据分为三组，返回标签和聚类中心
    data_matrix = data(:);
    
    % 计算距离矩阵并确定合适的eps参数
    Y = pdist(data_matrix);
    eps = 0.5 * median(Y);  % 使用中位数的一半作为eps
    minPts = 5;
    
    % 使用DBSCAN算法
    cluster_labels = dbscan(data_matrix, eps, 'MinPts', minPts);
    
    % 计算聚类中心（排除噪声点）
    k = max(cluster_labels);  % 获取聚类数（不包括噪声点）
    cluster_centers = zeros(k, 1);
    for i = 1:k
        cluster_centers(i) = mean(data(cluster_labels == i));
    end
    
    % 可视化结果
    figure;
    hold on;
    colors = lines(k);
    
    % 绘制噪声点（标签为-1）
    noise_idx = find(cluster_labels == -1);
    if ~isempty(noise_idx)
        scatter(noise_idx, data(noise_idx), 20, [0.5 0.5 0.5], 'filled', 'MarkerFaceAlpha', 0.3);
    end
    
    % 绘制聚类点和中心
    for i = 1:k
        idx = find(cluster_labels == i);
        scatter(idx, data(idx), 20, colors(i,:), 'filled', 'MarkerFaceAlpha', 0.5);
        line([min(idx) max(idx)], [cluster_centers(i) cluster_centers(i)], 'Color', colors(i,:), 'LineWidth', 2);
    end
    
    title('DBSCAN聚类结果');
    xlabel('数据索引');
    ylabel('值');
    legend_entries = cell(1, k+1);
    legend_entries{1} = '噪声';
    for i = 1:k
        legend_entries{i+1} = ['聚类', num2str(i)];
    end
    legend(legend_entries, 'Location', 'best');
    grid on;
end