clc,clear;

% % 加载包含元胞数组的.mat文件，假设文件名为data.mat，元胞数组名为cellData
% load('changed_CCF_data_dir.mat'); 
% 
% % 提取第一行作为横坐标（方法名称）
% xLabels = changed_CCF_data_dir(1, :);
% % 提取最后一行（第5行）作为纵坐标数据
% yData = changed_CCF_data_dir(4, :);
% 
% % 将元胞中的字符串横坐标转换为分类变量（用于柱状图横坐标）
% changed_data_head={'Ancuti et al.[18]','Ancuti et al.[19]','RGHS [20]','ULAP[23]','Chen et al.[24]',' IBLA[25]','Water-Net [7]','FUnIE-GAN[28]',...
%     'U-Former[29]','SC-Net[35]','Shallow-Net [37]'
%     };
% x = categorical(cellstr(changed_data_head), cellstr(changed_data_head));
% 
% % 创建柱状图
% b = bar(x, cell2mat(yData));
% 
% b.FaceColor = [0.4, 0.6, 0.8];
% b.EdgeColor = 'white';    % 边框颜色
% b.EdgeAlpha = 0.2;        % 边框透明度
% b.BarWidth = 0.7;         % 柱宽（0.1~1.0，默认 0.8）
% 
% hold on;
% 
% % 在柱子上方添加数值标签
% for i = 1:length(yData)
%     text(b.XData(i), b.YData(i) + 0.1, num2str(cell2mat(yData(i)),'%.2f'), ...
%          'HorizontalAlignment', 'center', 'FontSize', 10);
% end
% hold off;
% 
% % 添加阴影效果
% set(gca, 'Box', 'off');   % 关闭图形边框
% 
% % 设置横坐标标签
% xlabel('Methods');
% % 设置纵坐标标签
% ylabel('CCF Relative Gain');
% % 设置图表标题
% title('CCF');



% 让横坐标标签完整显示（避免重叠等问题）
% xtickangle(45); 

% % 定义横坐标标签（元胞数组形式）
% xLabels = {'m1', 'm2', 'm3', 'm4'};
% % 定义纵坐标数据
% yData = [1, 2, 3, 4];
% 
% % 将元胞数组转换为分类变量作为横坐标
% x = categorical(xLabels);
% 
% % 创建柱状图
% bar(x, yData);
% 
% % 设置图表标题和坐标轴标签
% title('示例柱状图');
% xlabel('横坐标');
% ylabel('纵坐标');
% 
% % 设置网格线
% grid on;

% 数据集名称
datasetNames = {'UEB[8]', 'SAUD[14]', 'CUIS', 'UIQ[1]', 'UCCS[1]'};
x = categorical(datasetNames);
% 两种指标（CF 和 SI）的数据，每行对应一个数据集的指标值
dataCF = [0.95, 0.78, 0.9, 0.6, 0.37];
dataSI = [0.83, 0.93, 0.9, 0.63, 0.34];

% 将数据组合成矩阵，每行对应一个数据集，每列对应一个指标
data = [dataCF; dataSI];

% 绘制分组柱状图，bar 函数的第三个参数设置为 'grouped' 表示分组显示
b = bar(x,data, 'grouped');

% 设置柱状图的颜色，这里设置两种颜色分别对应 CF 和 SI
set(b(1), 'FaceColor', [0.2, 0.5, 0.8]);  % CF 对应的柱子颜色
set(b(2), 'FaceColor', [0.8, 0.4, 0.4]);  % SI 对应的柱子颜色

% 设置横坐标刻度标签为数据集名称
set(gca, 'XTickLabel', datasetNames);

% 设置坐标轴标签和标题
xlabel('Underwater Image Dataset', 'FontSize', 10);
ylabel('Relative ranges', 'FontSize', 10);
title('Relative ranges', 'FontSize', 12);

% 添加图例
legend('CF', 'SI', 'Location', 'northeast');

% 让横坐标标签旋转一定角度，避免重叠，可根据实际情况调整角度
xtickangle(45);






