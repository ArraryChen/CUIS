function [cluster_labels, cluster_centers] = gmm_1d(data)
% 使用高斯混合模型将1D数据分为三组，返回标签和聚类中心
    data_matrix = data(:);
    options = statset('MaxIter', 1000);
    
    % 拟合高斯混合模型
    gmm = fitgmdist(data_matrix, 3,'Options',options);
    cluster_labels = cluster(gmm, data_matrix);
    
    % 获取聚类中心（即高斯分布的均值）
    cluster_centers = gmm.mu;
    
    % 可视化结果
    figure;
    hold on;
    colors = lines(3);
    
    % 绘制原始数据点
    for i = 1:3
        idx = find(cluster_labels == i);
        scatter(idx, data(idx), 20, colors(i,:), 'filled', 'MarkerFaceAlpha', 0.5);
        % 绘制聚类中心
        line([min(idx) max(idx)], [cluster_centers(i) cluster_centers(i)], 'Color', colors(i,:), 'LineWidth', 2);
    end
    


    % 绘制高斯分布曲线
    x = linspace(min(data), max(data), 1000);
    for i = 1:3
        y = gmm.ComponentProportion(i) * normpdf(x, gmm.mu(i), sqrt(gmm.Sigma(i)));
        % 缩放密度曲线以便在图中显示
        scale = length(data) * (max(data) - min(data)) / 1000;
        plot(x, y * scale + i*10, 'Color', colors(i,:), 'LineWidth', 2);
    end

    title('Gaussian Mixture Model clustering');
    xlabel('Index');
    ylabel('CCF score');
    % legend(scatter_handles, {'聚类1', '聚类2', '聚类3'}, 'Location', 'best');
    legend('CUIS-silght','','CUIS-medium', '','CUIS-severe','Location', 'best');

    grid on;
end