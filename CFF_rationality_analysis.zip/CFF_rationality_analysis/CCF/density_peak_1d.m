function [cluster_labels, cluster_centers] = density_peak_1d(data)
% 使用密度峰值聚类将1D数据分为三组，返回标签和聚类中心
    data_matrix = data(:);
    
    % 计算距离矩阵
    Y = pdist(data_matrix);
    D = squareform(Y);
    
    % 计算截断距离dc（使用中位数）
    dc = median(Y);
    
    % 计算局部密度rho
    n = length(data);
    rho = zeros(n, 1);
    for i = 1:n
        rho(i) = sum(exp(-(D(i,:)/dc).^2));
    end
    
    % 计算delta（到密度更高点的最小距离）
    [sorted_rho, idx] = sort(rho, 'descend');
    delta = zeros(n, 1);
    delta(idx(1)) = max(D(idx(1), :));  % 密度最高的点
    
    for i = 2:n
        delta(idx(i)) = min(D(idx(i), idx(1:i-1)));
    end
    
    % 识别聚类中心
    [~, center_idx] = sort(rho .* delta, 'descend');
    centers = center_idx(1:3);  % 前3个点作为中心
    
    % 分配数据点到最近的中心
    cluster_labels = zeros(n, 1);
    for i = 1:n
        [~, nearest_center] = min(D(i, centers));
        cluster_labels(i) = nearest_center;
    end
    
    % 计算聚类中心（使用分配后的点重新计算）
    cluster_centers = zeros(3, 1);
    for i = 1:3
        cluster_centers(i) = mean(data(cluster_labels == i));
    end
    
    % 可视化决策图（密度 vs 距离）
    figure;
    scatter(rho, delta, 20, 'filled');
    hold on;
    scatter(rho(centers), delta(centers), 50, 'r', 'filled', 'MarkerEdgeColor', 'k');
    title('密度峰值聚类决策图');
    xlabel('局部密度 \rho');
    ylabel('距离 \delta');
    legend('数据点', '聚类中心', 'Location', 'best');
    grid on;
    
    % 可视化聚类结果
    figure;
    hold on;
    colors = lines(3);
    for i = 1:3
        idx = find(cluster_labels == i);
        scatter(idx, data(idx), 20, colors(i,:), 'filled', 'MarkerFaceAlpha', 0.5);
        % 绘制聚类中心
        line([min(idx) max(idx)], [cluster_centers(i) cluster_centers(i)], 'Color', colors(i,:), 'LineWidth', 2);
    end
    title('密度峰值聚类结果');
    xlabel('数据索引');
    ylabel('值');
    legend('聚类1', '聚类2', '聚类3', 'Location', 'best');
    grid on;
end