addpath('F:\image_enhancement\CFF_rationality_analysis\tools\CCF');

CUIS_CCF_method3_array= [];
for i = 1:1000
    im = imread(['F:\image_enhancement\UIE\Dataset-CUIS\CUIS-2\RGHS\',num2str(i),'.png']);
    quality = CCF(im);
    CUIS_CCF_method3_array = [CUIS_CCF_method3_array,quality];
    fprintf('end %d\n',i);
end

disp(mean(CUIS_CCF_method3_array));
save('CUIS_CCF_method3_array','CUIS_CCF_method3_array');

