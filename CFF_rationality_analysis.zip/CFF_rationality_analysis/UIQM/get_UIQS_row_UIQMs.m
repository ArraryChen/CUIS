clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\UIQM');
Coe=[0.0282    0.2953    3.5753];

UIQS_UIQM_row_array= [];
UIQS_UICM_row_array= [];
UIQS_UISM_row_array= [];
UIQS_UIConM_row_array= [];

for j = 1:726
    if (0<j) && (j<10)
        im_name = ['F:\image_enhancement\UIE\Dataset-UIQS\before\','C_','00',num2str(j),'.jpg'];
    elseif (9<j) && (j<100)
        im_name = ['F:\image_enhancement\UIE\Dataset-UIQS\before\','C_','0',num2str(j),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UIQS\before\','C_',num2str(j),'.jpg'];
    end

    im = imread(im_name);
    [~, colrfulness, sharpness, contrast] = UIQM(im);
    UIQM_quality = Coe(1)*colrfulness+Coe(2)*sharpness+Coe(3)*contrast;
    UIQS_UIQM_row_array = [UIQS_UIQM_row_array,UIQM_quality];
    UIQS_UICM_row_array = [UIQS_UICM_row_array,colrfulness];
    UIQS_UISM_row_array = [UIQS_UISM_row_array,sharpness];
    UIQS_UIConM_row_array = [UIQS_UIConM_row_array,contrast];
    fprintf('end %d\n',j);
end

save('UIQS_UIQM_row_array','UIQS_UIQM_row_array');
save('UIQS_UICM_row_array','UIQS_UICM_row_array');
save('UIQS_UISM_row_array','UIQS_UISM_row_array');
save('UIQS_UIConM_row_array','UIQS_UIConM_row_array');

