path_data = {
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-2\fusion-based-1\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-2\fusion-based-2\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-2\RGHS\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-3\ULAP\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-3\Chen\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-3\IBLA\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-1\Water-Net\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-1\FUnIE-GAN\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-1\U-Former\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-1\SCNet\';
    'F:\image_enhancement\UIE\Dataset-CUIS\CUIS-1\Shallow-Net\';
};
save("path_data","path_data");