clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\UIQM');
load("path_data.mat");
Coe=[0.0282    0.2953    3.5753];


CUIS_UIQM_array= [];
CUIS_UICM_array= [];
CUIS_UISM_array= [];
CUIS_UIConM_array= [];

for i = 1:11
    for j = 1:1000
        im = imread([path_data{i},num2str(j),'.png']);
        [~, colrfulness, sharpness, contrast] = UIQM(im);
        UIQM_quality = Coe(1)*colrfulness+Coe(2)*sharpness+Coe(3)*contrast;
        CUIS_UIQM_array(i,j) = UIQM_quality;
        CUIS_UICM_array(i,j) = colrfulness;
        CUIS_UISM_array(i,j) = sharpness;
        CUIS_UIConM_array(i,j) = contrast;
        fprintf('end %d:%d\n',i,j);
    end
end

save('CUIS_UIQM_array','CUIS_UIQM_array');
save('CUIS_UICM_array','CUIS_UICM_array');
save('CUIS_UISM_array','CUIS_UISM_array');
save('CUIS_UIConM_array','CUIS_UIConM_array');

