clc,clear;


addpath('F:\image_enhancement\CFF_rationality_analysis\tools\UIQM');
Coe=[0.0282    0.2953    3.5753];

SAUD_UIQM_row_array= [];
SAUD_UICM_row_array= [];
SAUD_UISM_row_array= [];
SAUD_UIConM_row_array= [];


for i = 1:100
    im = imread(['F:\image_enhancement\SAUD-NUIQ\',num2str(i),'.png']);
    [~, colrfulness, sharpness, contrast] = UIQM(im);
    UIQM_quality = Coe(1)*colrfulness+Coe(2)*sharpness+Coe(3)*contrast;
    SAUD_UIQM_row_array = [SAUD_UIQM_row_array,UIQM_quality];
    SAUD_UICM_row_array = [SAUD_UICM_row_array,colrfulness];
    SAUD_UISM_row_array = [SAUD_UISM_row_array,sharpness];
    SAUD_UIConM_row_array = [SAUD_UIConM_row_array,contrast];
    fprintf('end %d\n',i);
end


save('SAUD_UIQM_row_array','SAUD_UIQM_row_array');
save('SAUD_UICM_row_array','SAUD_UICM_row_array');
save('SAUD_UISM_row_array','SAUD_UISM_row_array');
save('SAUD_UIConM_row_array','SAUD_UIConM_row_array');

