% get_CUIS_row_UIQMs;
% get_CUIS_enhance_UIQMs;
clc,clear;

load('CUIS_UIQM_row_array.mat');
load('CUIS_UICM_row_array.mat');
load('CUIS_UISM_row_array.mat');
load('CUIS_UIConM_row_array.mat');

load('CUIS_UIQM_array.mat');
load('CUIS_UICM_array.mat');
load('CUIS_UISM_array.mat');
load('CUIS_UIConM_array.mat');

valid_idx = ~isinf(CUIS_UIQM_row_array);
row_UIQM_data = mean(CUIS_UIQM_row_array(valid_idx));

valid_idx = ~isinf(CUIS_UICM_row_array);
row_UICM_data = mean(CUIS_UICM_row_array(valid_idx));

valid_idx = ~isinf(CUIS_UISM_row_array);
row_UISM_data = mean(CUIS_UISM_row_array(valid_idx));

valid_idx = ~isinf(CUIS_UIConM_row_array);
row_UIConM_data = mean(CUIS_UIConM_row_array(valid_idx));

UIQM_data_abs = [];
UICM_data_abs = [];
UISM_data_abs = [];
UIConM_data_abs = [];

UIQM_data_changed_abs = [];
UICM_data_changed_abs = [];
UISM_data_changed_abs = [];
UIConM_data_changed_abs = [];

UIQM_data_changed_rel = [];
UICM_data_changed_rel = [];
UISM_data_changed_rel = [];
UIConM_data_changed_rel = [];

for i=1:11

    UIQM_data_abs = [UIQM_data_abs,nanmean(CUIS_UIQM_array(i,:))];
    UICM_data_abs = [UICM_data_abs,nanmean(CUIS_UICM_array(i,:))];
    UISM_data_abs = [UISM_data_abs,nanmean(CUIS_UISM_array(i,:))];
    UIConM_data_abs = [UIConM_data_abs,nanmean(CUIS_UIConM_array(i,:))];

    UIQM_data_changed_abs = [UIQM_data_changed_abs,nanmean(CUIS_UIQM_array(i,:))-row_UIQM_data];
    UICM_data_changed_abs = [UICM_data_changed_abs,nanmean(CUIS_UICM_array(i,:))-row_UICM_data];
    UISM_data_changed_abs = [UISM_data_changed_abs,nanmean(CUIS_UISM_array(i,:))-row_UISM_data];
    UIConM_data_changed_abs = [UIConM_data_changed_abs,nanmean(CUIS_UIConM_array(i,:))-row_UIConM_data];

    UIQM_data_changed_rel = [UIQM_data_changed_rel,(nanmean(CUIS_UIQM_array(i,:))-row_UIQM_data)/row_UIQM_data];
    UICM_data_changed_rel = [UICM_data_changed_rel,(nanmean(CUIS_UICM_array(i,:))-row_UICM_data)/row_UICM_data];
    UISM_data_changed_rel = [UISM_data_changed_rel,(nanmean(CUIS_UISM_array(i,:))-row_UISM_data)/row_UISM_data];
    UIConM_data_changed_rel = [UIConM_data_changed_rel,(nanmean(CUIS_UIConM_array(i,:))-row_UIConM_data)/row_UIConM_data];


end

data_head={'row';'method1';'method2';'method3';'method4';'method5';'method6';'method7';'method8';...
    'method9';'method10';'method11'
    };

all_UIQM_data = [CUIS_UIQM_row_array;CUIS_UIQM_array];
all_UICM_data = [CUIS_UICM_row_array;CUIS_UICM_array];
all_UISM_data = [CUIS_UISM_row_array;CUIS_UISM_array];
all_UIConM_data = [CUIS_UIConM_row_array;CUIS_UIConM_array];

all_UIQM_data_dir = [data_head,num2cell(all_UIQM_data)];
all_UICM_data_dir = [data_head,num2cell(all_UICM_data)];
all_UISM_data_dir = [data_head,num2cell(all_UISM_data)];
all_UIConM_data_dir = [data_head,num2cell(all_UIConM_data)];

changed_data_head={'method1','method2','method3','method4','method5','method6','method7','method8',...
    'method9','method10','method11'
    };
changed_UIQM_data_dir = [changed_data_head;num2cell(UIQM_data_abs);num2cell(UIQM_data_changed_abs);num2cell(UIQM_data_changed_rel)];
changed_UICM_data_dir = [changed_data_head;num2cell(UICM_data_abs);num2cell(UICM_data_changed_abs);num2cell(UICM_data_changed_rel)];
changed_UISM_data_dir = [changed_data_head;num2cell(UISM_data_abs);num2cell(UISM_data_changed_abs);num2cell(UISM_data_changed_rel)];
changed_UIConM_data_dir = [changed_data_head;num2cell(UIConM_data_abs);num2cell(UIConM_data_changed_abs);num2cell(UIConM_data_changed_rel)];

save('changed_UIQM_data_dir','changed_UIQM_data_dir');
save('changed_UICM_data_dir','changed_UICM_data_dir');
save('changed_UISM_data_dir','changed_UISM_data_dir');
save('changed_UIConM_data_dir','changed_UIConM_data_dir');


