clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\UIQM');
Coe=[0.0282    0.2953    3.5753];


UIEB_UIQM_row_array= [];
UIEB_UICM_row_array= [];
UIEB_UISM_row_array= [];
UIEB_UIConM_row_array= [];


for j = 1:950
    im = imread(['F:\image_enhancement\UIE\Dataset-UIEB\before\',num2str(j),'.png']);
    [~, colrfulness, sharpness, contrast] = UIQM(im);
    UIQM_quality = Coe(1)*colrfulness+Coe(2)*sharpness+Coe(3)*contrast;
    UIEB_UIQM_row_array = [UIEB_UIQM_row_array,UIQM_quality];
    UIEB_UICM_row_array = [UIEB_UICM_row_array,colrfulness];
    UIEB_UISM_row_array = [UIEB_UISM_row_array,sharpness];
    UIEB_UIConM_row_array = [UIEB_UIConM_row_array,contrast];
    fprintf('end %d\n',j);
end


save('UIEB_UIQM_row_array','UIEB_UIQM_row_array');
save('UIEB_UICM_row_array','UIEB_UICM_row_array');
save('UIEB_UISM_row_array','UIEB_UISM_row_array');
save('UIEB_UIConM_row_array','UIEB_UIConM_row_array');