clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\UIQM');
Coe=[0.0282    0.2953    3.5753];

CUIS_UIQM_row_array= [];
CUIS_UICM_row_array= [];
CUIS_UISM_row_array= [];
CUIS_UIConM_row_array= [];

for i = 1:200
    im = imread(['F:\image_enhancement\CUIS-raw\CUIS-slight\',num2str(i),'.png']);
    [~, colrfulness, sharpness, contrast] = UIQM(im);
    UIQM_quality = Coe(1)*colrfulness+Coe(2)*sharpness+Coe(3)*contrast;
    CUIS_UIQM_row_array = [CUIS_UIQM_row_array,UIQM_quality];
    CUIS_UICM_row_array = [CUIS_UICM_row_array,colrfulness];
    CUIS_UISM_row_array = [CUIS_UISM_row_array,sharpness];
    CUIS_UIConM_row_array = [CUIS_UIConM_row_array,contrast];
    fprintf('end %d\n',i);
end


for i = 201:800
    im = imread(['F:\image_enhancement\CUIS-raw\CUIS-general\',num2str(i),'.png']);
    [~, colrfulness, sharpness, contrast] = UIQM(im);
    UIQM_quality = Coe(1)*colrfulness+Coe(2)*sharpness+Coe(3)*contrast;
    CUIS_UIQM_row_array = [CUIS_UIQM_row_array,UIQM_quality];
    CUIS_UICM_row_array = [CUIS_UICM_row_array,colrfulness];
    CUIS_UISM_row_array = [CUIS_UISM_row_array,sharpness];
    CUIS_UIConM_row_array = [CUIS_UIConM_row_array,contrast];
    fprintf('end %d\n',i);
end


for i = 801:1000
    im = imread(['F:\image_enhancement\CUIS-raw\CUIS-severe\',num2str(i),'.png']);
    [~, colrfulness, sharpness, contrast] = UIQM(im);
    UIQM_quality = Coe(1)*colrfulness+Coe(2)*sharpness+Coe(3)*contrast;
    CUIS_UIQM_row_array = [CUIS_UIQM_row_array,UIQM_quality];
    CUIS_UICM_row_array = [CUIS_UICM_row_array,colrfulness];
    CUIS_UISM_row_array = [CUIS_UISM_row_array,sharpness];
    CUIS_UIConM_row_array = [CUIS_UIConM_row_array,contrast];
    fprintf('end %d\n',i);
end


save('CUIS_UIQM_row_array','CUIS_UIQM_row_array');
save('CUIS_UICM_row_array','CUIS_UICM_row_array');
save('CUIS_UISM_row_array','CUIS_UISM_row_array');
save('CUIS_UIConM_row_array','CUIS_UIConM_row_array');

