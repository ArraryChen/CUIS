clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\tools\UIQM');
Coe=[0.0282    0.2953    3.5753];

UCCS_bg_UIQM_row_array= [];
UCCS_bg_UICM_row_array= [];
UCCS_bg_UISM_row_array= [];
UCCS_bg_UIConM_row_array= [];

for j = 1:100
    if j-1<10
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','bg_','0',num2str(j-1),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','bg_',num2str(j-1),'.jpg'];
    end

    im = imread(im_name);
    [~, colrfulness, sharpness, contrast] = UIQM(im);
    UIQM_quality = Coe(1)*colrfulness+Coe(2)*sharpness+Coe(3)*contrast;
    UCCS_bg_UIQM_row_array = [UCCS_bg_UIQM_row_array,UIQM_quality];
    UCCS_bg_UICM_row_array = [UCCS_bg_UICM_row_array,colrfulness];
    UCCS_bg_UISM_row_array = [UCCS_bg_UISM_row_array,sharpness];
    UCCS_bg_UIConM_row_array = [UCCS_bg_UIConM_row_array,contrast];
    fprintf('end %d\n',j);
end

save('UCCS_bg_UIQM_row_array','UCCS_bg_UIQM_row_array');
save('UCCS_bg_UICM_row_array','UCCS_bg_UICM_row_array');
save('UCCS_bg_UISM_row_array','UCCS_bg_UISM_row_array');
save('UCCS_bg_UIConM_row_array','UCCS_bg_UIConM_row_array');


UCCS_blue_UIQM_row_array= [];
UCCS_blue_UICM_row_array= [];
UCCS_blue_UISM_row_array= [];
UCCS_blue_UIConM_row_array= [];

for j = 1:100
    if j-1<10
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','blue_','0',num2str(j-1),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','blue_',num2str(j-1),'.jpg'];
    end

    im = imread(im_name);
    [~, colrfulness, sharpness, contrast] = UIQM(im);
    UIQM_quality = Coe(1)*colrfulness+Coe(2)*sharpness+Coe(3)*contrast;
    UCCS_blue_UIQM_row_array = [UCCS_blue_UIQM_row_array,UIQM_quality];
    UCCS_blue_UICM_row_array = [UCCS_blue_UICM_row_array,colrfulness];
    UCCS_blue_UISM_row_array = [UCCS_blue_UISM_row_array,sharpness];
    UCCS_blue_UIConM_row_array = [UCCS_blue_UIConM_row_array,contrast];
    fprintf('end %d\n',j);
end

save('UCCS_blue_UIQM_row_array','UCCS_blue_UIQM_row_array');
save('UCCS_blue_UICM_row_array','UCCS_blue_UICM_row_array');
save('UCCS_blue_UISM_row_array','UCCS_blue_UISM_row_array');
save('UCCS_blue_UIConM_row_array','UCCS_blue_UIConM_row_array');




UCCS_green_UIQM_row_array= [];
UCCS_green_UICM_row_array= [];
UCCS_green_UISM_row_array= [];
UCCS_green_UIConM_row_array= [];


for j = 1:100
    if j-1<10
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','green_','0',num2str(j-1),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','green_',num2str(j-1),'.jpg'];
    end

    im = imread(im_name);
    [~, colrfulness, sharpness, contrast] = UIQM(im);
    UIQM_quality = Coe(1)*colrfulness+Coe(2)*sharpness+Coe(3)*contrast;
    UCCS_green_UIQM_row_array = [UCCS_green_UIQM_row_array,UIQM_quality];
    UCCS_green_UICM_row_array = [UCCS_green_UICM_row_array,colrfulness];
    UCCS_green_UISM_row_array = [UCCS_green_UISM_row_array,sharpness];
    UCCS_green_UIConM_row_array = [UCCS_green_UIConM_row_array,contrast];
    fprintf('end %d\n',j);
end

save('UCCS_green_UIQM_row_array','UCCS_green_UIQM_row_array');
save('UCCS_green_UICM_row_array','UCCS_green_UICM_row_array');
save('UCCS_green_UISM_row_array','UCCS_green_UISM_row_array');
save('UCCS_green_UIConM_row_array','UCCS_green_UIConM_row_array');

