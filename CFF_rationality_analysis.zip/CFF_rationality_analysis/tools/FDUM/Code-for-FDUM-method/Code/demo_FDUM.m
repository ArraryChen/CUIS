clc,clear;
Coe=[0.2982    0.4439    0.028];

for i = 1 : 200
    disp(i)
    I=imread(['F:\图像增强\UIE\Dataset-CUIS\CUIS-2\fusion-based-1\',num2str(i),'.png']);
    Color=Colorfulness(I);
    Con=Contrast(I);
    Sharp=UIQMSharpness(I);
    Final=Coe(1)*Color+Coe(2)*Con+Coe(3)*Sharp
    Value(i,:)=Final;
end


