clc,clear;

array = [];
for i = 1 : 200
    im=imread(['F:\图像增强\UIE\Dataset-CUIS\CUIS-2\fusion-based-1\',num2str(i),'.png']);
    [UIQM_norm, colrfulness, sharpness, contrast] = UIQM(im);
    array = [array,UIQM_norm];
    fprintf('end %d\n',i);
end
mean(array)