clc;
clear;
avg = 0;
c1 = 0.0282;
c2 = 0.2953;
c3 = 3.5753;
for i = 1:200
    I = imread(['F:\image_enhancement\UIE\Dataset-CUIS\CUIS-2\fusion-based-1\',num2str(i),'.png']);
    [UIQM_norm, colrfulness, sharpness, contrast] = UIQM(I);
    v = c1*colrfulness + c2*sharpness + c3*contrast;
    avg = avg + v;
    fprintf('end %d\n',i);
end
avg = avg / 200;
disp(avg);