clc;clear all;
%% para_set
%% for ten enhanced images of one raw image:groups = 1; numbers_in_each_group = 10;
%% for ten enhanced images of ten raw image:groups = 10; numbers_in_each_group = 1;
groups = 1;
numbers_in_each_group = 10;
%% feature extraction
for i=1:10
I = imread(['D:\水下图像主观评分\Benchmark\Enhanced\all\',num2str(i),'.png']);
final_feature(i,:) = NUIQ_feature_extraction(I);
end
final_feature = final_feature';
final_feature = mapminmax(final_feature,0,1);
final_feature = final_feature';
%% score prediction
predictions = test_model(final_feature,groups,numbers_in_each_group);

