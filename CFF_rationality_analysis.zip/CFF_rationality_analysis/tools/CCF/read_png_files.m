function pngFilenames = read_png_files(folderPath)
    % 功能：读取指定文件夹下所有.png格式的文件名称（含扩展名）
    % 输入：folderPath - 目标文件夹路径（例如：'F:/images/'）
    % 输出：pngFilenames - 字符串数组，存储所有.png文件名
    
    % 检查文件夹是否存在
    if ~exist(folderPath, 'dir')
        error(['文件夹不存在：', folderPath]);
    end
    
    % 使用dir函数获取所有.png文件
    fileList = dir(fullfile(folderPath, '*.png'));
    
    % 提取文件名（含扩展名）
    pngFilenames = {fileList.name};
    
    % 示例输出：
    % pngFilenames = ["image1.png", "image2.png", ...]
end