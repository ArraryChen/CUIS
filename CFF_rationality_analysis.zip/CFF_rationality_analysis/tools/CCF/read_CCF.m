clear all
clc


% 调用函数获取文件名


CFF_array = [];
for i = 1:200
    im = imread(['F:\图像增强\CUIS-raw\CUIS-slight\',num2str(i),'.png']);
    CFF_array = [CFF_array,CCF(im)];
    fprintf('end %d\n',i);
end

CCF_enhance_chen = mean(CFF_array);



% im = imread("F:\图像增强\images\65-raw.png");
% CCF_row = CCF(im);
% im = imread("F:\图像增强\images\65-fusion-1.png");
% CCF_enhence = CCF(im);
% CCF_enhence - CCF_row

