clc;
clear;
avg = 0;
for i = 1:200
    I = imread(['F:\图像增强\UIE\Dataset-CUIS\CUIS-2\fusion-based-1\',num2str(i),'.png']);
    u = UCIQE(I);
    avg = avg + u;
    fprintf('end %d\n',i);
end
avg = avg / 200;
disp(avg);