clc,clear;

addpath('F:\image_enhancement\CFF_rationality_analysis\CCF');
addpath('F:\image_enhancement\CFF_rationality_analysis\FDUM');
addpath('F:\image_enhancement\CFF_rationality_analysis\UCIQE');
addpath('F:\image_enhancement\CFF_rationality_analysis\UIQM');
addpath('F:\image_enhancement\CFF_rationality_analysis\NUIQ\NUIQ_Metric');

load('changed_CCF_data_dir.mat');
load('changed_FDUM_data_dir.mat');
load('changed_UCIQE_data_dir.mat');
load('changed_UIQM_data_dir.mat');
load('changed_UICM_data_dir.mat');
load('changed_UIConM_data_dir.mat');
load('changed_UISM_data_dir.mat');
load('changed_NUIQ_data_dir.mat');

changed_data_head={'Ancuti et al.[18]','Ancuti et al.[19]','RGHS [20]','ULAP[23]','Chen et al.[24]',' IBLA[25]','Water-Net [7]','FUnIE-GAN[28]',...
    'U-Former[29]','SC-Net[35]','Shallow-Net [37]'
    };
x = categorical(cellstr(changed_data_head), cellstr(changed_data_head));

y1 = [
    cell2mat(changed_CCF_data_dir(4, :));
    cell2mat(changed_FDUM_data_dir(4, :));
    cell2mat(changed_UCIQE_data_dir(4, :));
    cell2mat(changed_NUIQ_data_dir(4, :));
    ];
y2 = [
    cell2mat(changed_UIQM_data_dir(4, :));
    cell2mat(changed_UICM_data_dir(4, :));
    cell2mat(changed_UIConM_data_dir(4, :));
    cell2mat(changed_UISM_data_dir(4, :));
    ];
y3 = [
    cell2mat(changed_CCF_data_dir(4, :));
    cell2mat(changed_FDUM_data_dir(4, :));
    cell2mat(changed_UCIQE_data_dir(4, :));
    cell2mat(changed_NUIQ_data_dir(4, :));
    cell2mat(changed_UIQM_data_dir(4, :));
    cell2mat(changed_UICM_data_dir(4, :));
    cell2mat(changed_UIConM_data_dir(4, :));
    cell2mat(changed_UISM_data_dir(4, :));
    ];

figure(1)
% 绘制分组柱状图，bar 函数的第三个参数设置为 'grouped' 表示分组显示
b = bar(x,y1, 'grouped');

% 设置柱状图的颜色，这里设置两种颜色分别对应 CF 和 SI
set(b(1), 'FaceColor', [0.3, 0.7, 0.9]);
set(b(2), 'FaceColor', [0.9, 0.4, 0.4]);
set(b(3), 'FaceColor', [0.3, 0.8, 0.5]);
set(b(4), 'FaceColor', [0.8, 0.6, 0.4]); 



% 设置横坐标刻度标签为数据集名称
% set(gca, 'XTickLabel', datasetNames);

% 设置坐标轴标签和标题
xlabel('UIE methods', 'FontSize', 10);
ylabel('Relative Improvement Rate', 'FontSize', 10);
title('CUIS dataset', 'FontSize', 12);

% 添加图例
legend('CCF', 'FDUM', 'UCIQE', 'NUIQ','Location', 'northeast');

% 让横坐标标签旋转一定角度，避免重叠，可根据实际情况调整角度
xtickangle(45);

figure(2)

b = bar(x,y2, 'grouped');

set(b(1), 'FaceColor', [0.0, 0.45, 0.74]);
set(b(2), 'FaceColor', [0.85, 0.33, 0.10]);
set(b(3), 'FaceColor', [0.13, 0.67, 0.25]);
set(b(4), 'FaceColor', [0.93, 0.69, 0.13]);

% 设置横坐标刻度标签为数据集名称
% set(gca, 'XTickLabel', datasetNames);

% 设置坐标轴标签和标题
xlabel('UIE methods', 'FontSize', 10);
ylabel('Relative Improvement Rate', 'FontSize', 10);
title('CUIS dataset', 'FontSize', 12);

% 添加图例
legend('UIQM', 'UICM', 'UIConM', 'UISM','Location', 'northeast');

% 让横坐标标签旋转一定角度，避免重叠，可根据实际情况调整角度
xtickangle(45);

figure(3)

b = bar(x,y3, 'grouped');

set(b(1), 'FaceColor', [0.0, 0.45, 0.74]);   % 深蓝色（原颜色1）
set(b(2), 'FaceColor', [0.85, 0.33, 0.10]);  % 橙红色（原颜色2）
set(b(3), 'FaceColor', [0.13, 0.67, 0.25]);  % 深绿色（原颜色3）
set(b(4), 'FaceColor', [0.93, 0.69, 0.13]);  % 金黄色（原颜色4）
set(b(5), 'FaceColor', [0.55, 0.27, 0.56]);  % 深紫色（新增）
set(b(6), 'FaceColor', [0.49, 0.46, 0.37]);  % 灰褐色（新增）
set(b(7), 'FaceColor', [0.64, 0.16, 0.16]);  % 深红色（新增）
set(b(8), 'FaceColor', [0.2, 0.63, 0.79]);   % 天蓝色（新增）


% 设置坐标轴标签和标题
xlabel('UIE methods', 'FontSize', 10);
ylabel('Relative Improvement Rate', 'FontSize', 10);
title('CUIS dataset', 'FontSize', 12);

% 添加图例
legend('CCF', 'FDUM', 'UCIQE', 'NUIQ','UIQM', 'UICM', 'UIConM', 'UISM','Location', 'northeast');

% 让横坐标标签旋转一定角度，避免重叠，可根据实际情况调整角度
xtickangle(45);