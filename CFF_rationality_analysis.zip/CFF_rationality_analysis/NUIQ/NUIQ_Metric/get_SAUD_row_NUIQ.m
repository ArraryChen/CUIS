clc,clear;

groups = 1;
numbers_in_each_group = 100;


SAUD_NUIQ_row_array= [];
for i = 1:100
    im = imread(['F:\image_enhancement\SAUD-NUIQ\',num2str(i),'.png']);
    final_feature(i,:) = NUIQ_feature_extraction(im);
    fprintf('end %d\n',i);
end

final_feature = final_feature';
final_feature = mapminmax(final_feature,0,1);
final_feature = final_feature';
%% score prediction
quality = test_model(final_feature,groups,numbers_in_each_group);
SAUD_NUIQ_row_array = [SAUD_NUIQ_row_array,quality'];

save('SAUD_NUIQ_row_array','SAUD_NUIQ_row_array');

