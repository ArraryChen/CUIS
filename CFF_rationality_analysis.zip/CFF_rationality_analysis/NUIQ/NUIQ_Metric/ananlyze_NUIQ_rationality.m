clc,clear;

% get_CUIS_row_NUIQ;
% get_CUIS_enhance_NUIQ;


load('CUIS_NUIQ_row_array.mat');
load('CUIS_NUIQ_array.mat');

row_data = mean(CUIS_NUIQ_row_array);
data_changed_abs = [];
data_changed_rel = [];
data_abs = [];
for i=1:11
    data_abs = [data_abs,nanmean(CUIS_NUIQ_array(i,:))];
    data_changed_abs = [data_changed_abs,nanmean(CUIS_NUIQ_array(i,:))-row_data];
    data_changed_rel = [data_changed_rel,(nanmean(CUIS_NUIQ_array(i,:))-row_data)/row_data];
end

all_data = [CUIS_NUIQ_row_array;CUIS_NUIQ_array];

data_head={'row';'method1';'method2';'method3';'method4';'method5';'method6';'method7';'method8';...
    'method9';'method10';'method11'
    };
all_data_dir = [data_head,num2cell(all_data)];

changed_data_head={'method1','method2','method3','method4','method5','method6','method7','method8',...
    'method9','method10','method11'
    };
changed_NUIQ_data_dir = [changed_data_head;num2cell(data_abs);num2cell(data_changed_abs);num2cell(data_changed_rel)];

save('changed_NUIQ_data_dir','changed_NUIQ_data_dir');

