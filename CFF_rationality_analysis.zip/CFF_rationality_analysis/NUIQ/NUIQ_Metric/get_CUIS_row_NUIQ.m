clc,clear;


groups = 1;
numbers_in_each_group = 200;


CUIS_NUIQ_row_array= [];
for i = 1:200
    im = imread(['F:\image_enhancement\CUIS-raw\CUIS-slight\',num2str(i),'.png']);
    final_feature(i,:) = NUIQ_feature_extraction(im);
    fprintf('end %d\n',i);
end
final_feature = final_feature';
final_feature = mapminmax(final_feature,0,1);
final_feature = final_feature';
%% score prediction
quality = test_model(final_feature,groups,numbers_in_each_group);
CUIS_NUIQ_row_array = [CUIS_NUIQ_row_array,quality'];


groups = 1;
numbers_in_each_group = 600;


for i = 201:800
    im = imread(['F:\image_enhancement\CUIS-raw\CUIS-general\',num2str(i),'.png']);
    final_feature(i,:) = NUIQ_feature_extraction(im);
    fprintf('end %d\n',i);
end
final_feature = final_feature';
final_feature = mapminmax(final_feature,0,1);
final_feature = final_feature';
%% score prediction
quality = test_model(final_feature,groups,numbers_in_each_group);
CUIS_NUIQ_row_array = [CUIS_NUIQ_row_array,quality'];


groups = 1;
numbers_in_each_group = 200;


for i = 801:1000
    im = imread(['F:\image_enhancement\CUIS-raw\CUIS-severe\',num2str(i),'.png']);
    final_feature(i,:) = NUIQ_feature_extraction(im);
    fprintf('end %d\n',i);
end
final_feature = final_feature';
final_feature = mapminmax(final_feature,0,1);
final_feature = final_feature';
%% score prediction
quality = test_model(final_feature,groups,numbers_in_each_group);
CUIS_NUIQ_row_array = [CUIS_NUIQ_row_array,quality'];



disp(mean(CUIS_NUIQ_row_array));
save('CUIS_NUIQ_row_array','CUIS_NUIQ_row_array');

