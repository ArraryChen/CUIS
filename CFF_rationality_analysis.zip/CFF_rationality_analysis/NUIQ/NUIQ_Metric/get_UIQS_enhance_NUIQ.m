clc,clear;

load("path_data.mat");

UIQS_NUIQ_array= [];
groups = 1;
numbers_in_each_group = 726;

for i = 1:11
    for j = 1:726
        if (0<j) && (j<10)
            im_name = [UIQS_path_data{i},'C_','00',num2str(j),'.jpg'];
        elseif (9<j) && (j<100)
            im_name = [UIQS_path_data{i},'C_','0',num2str(j),'.jpg'];
        else
            im_name = [UIQS_path_data{i},'C_',num2str(j),'.jpg'];
        end

        im = imread(im_name);
        final_feature(j,:) = NUIQ_feature_extraction(im);
        fprintf('UIQS end %d:%d\n',i,j);
    end
    final_feature = final_feature';
    final_feature = mapminmax(final_feature,0,1);
    final_feature = final_feature';
    %% score prediction
    quality = test_model(final_feature,groups,numbers_in_each_group);
    UIQS_NUIQ_array(i,:) = quality';
end

save('UIQS_NUIQ_array',"UIQS_NUIQ_array");