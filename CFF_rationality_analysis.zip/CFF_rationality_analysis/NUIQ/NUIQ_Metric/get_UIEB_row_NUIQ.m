clc,clear;

groups = 1;
numbers_in_each_group = 950;

UIEB_NUIQ_row_array= [];
for j = 1:950
    im = imread(['F:\image_enhancement\UIE\Dataset-UIEB\before\',num2str(j),'.png']);
    final_feature(j,:) = NUIQ_feature_extraction(im);
    fprintf('end %d\n',j);
end

final_feature = final_feature';
final_feature = mapminmax(final_feature,0,1);
final_feature = final_feature';
%% score prediction
quality = test_model(final_feature,groups,numbers_in_each_group);
UIEB_NUIQ_row_array = [UIEB_NUIQ_row_array,quality'];


save('UIEB_NUIQ_row_array',"UIEB_NUIQ_row_array");