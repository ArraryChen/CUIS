clc,clear;

load("path_data.mat");
groups = 1;
numbers_in_each_group = 1000;

CUIS_NUIQ_array= [];
for i = 1:11
    for j = 1:1000
        im = imread([path_data{i},num2str(j),'.png']);
        final_feature(j,:) = NUIQ_feature_extraction(im);
        fprintf('end %d:%d\n',i,j);
    end
    final_feature = final_feature';
    final_feature = mapminmax(final_feature,0,1);
    final_feature = final_feature';
    %% score prediction
    quality = test_model(final_feature,groups,numbers_in_each_group);
    CUIS_NUIQ_array(i,:) = quality';
end
save('CUIS_NUIQ_array','CUIS_NUIQ_array');

