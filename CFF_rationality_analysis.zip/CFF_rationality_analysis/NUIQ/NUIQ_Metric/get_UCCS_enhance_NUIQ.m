clc,clear;

load("path_data.mat");

UCCS_bg_NUIQ_array= [];
groups = 1;
numbers_in_each_group = 100;

for i = 1:11
    for j = 1:100
        if j-1<10
            im_name = [UCCS_path_data{i},'bg_','0',num2str(j-1),'.jpg'];
        else
            im_name = [UCCS_path_data{i},'bg_',num2str(j-1),'.jpg'];
        end

        im = imread(im_name);
        final_feature(j,:) = NUIQ_feature_extraction(im);
        fprintf('UCCS BG end %d:%d\n',i,j);
    end
    final_feature = final_feature';
    final_feature = mapminmax(final_feature,0,1);
    final_feature = final_feature';
    %% score prediction
    quality = test_model(final_feature,groups,numbers_in_each_group);
    UCCS_bg_NUIQ_array(i,:) = quality';
end

UCCS_BLUE_NUIQ_array= [];
groups = 1;
numbers_in_each_group = 100;

for i = 1:11
    for j = 1:100
        if j-1<10
            im_name = [UCCS_path_data{i},'blue_','0',num2str(j-1),'.jpg'];
        else
            im_name = [UCCS_path_data{i},'blue_',num2str(j-1),'.jpg'];
        end

        im = imread(im_name);
        final_feature(j,:) = NUIQ_feature_extraction(im);
        fprintf('UCCS BLUE end %d:%d\n',i,j);
    end
    final_feature = final_feature';
    final_feature = mapminmax(final_feature,0,1);
    final_feature = final_feature';
    %% score prediction
    quality = test_model(final_feature,groups,numbers_in_each_group);
    UCCS_BLUE_NUIQ_array(i,:) = quality';
end

UCCS_GREEN_NUIQ_array= [];
groups = 1;
numbers_in_each_group = 100;

for i = 1:11
    for j = 1:100
        if j-1<10
            im_name = [UCCS_path_data{i},'green_','0',num2str(j-1),'.jpg'];
        else
            im_name = [UCCS_path_data{i},'green_',num2str(j-1),'.jpg'];
        end

        im = imread(im_name);
        final_feature(j,:) = NUIQ_feature_extraction(im);
        fprintf('UCCS GREEN end %d:%d\n',i,j);
    end
    final_feature = final_feature';
    final_feature = mapminmax(final_feature,0,1);
    final_feature = final_feature';
    %% score prediction
    quality = test_model(final_feature,groups,numbers_in_each_group);
    UCCS_GREEN_NUIQ_array(i,:) = quality';
end


save('UCCS_NUIQ_array','UCCS_bg_NUIQ_array','UCCS_BLUE_NUIQ_array','UCCS_GREEN_NUIQ_array');