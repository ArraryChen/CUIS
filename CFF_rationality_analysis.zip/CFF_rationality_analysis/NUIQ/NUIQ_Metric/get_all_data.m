clc,clear;



% get_CUIS_enhance_NUIQ;
% get_SAUD_enhance_NUIQ;
% get_UIEB_enhance_NUIQ;
% get_UIQS_enhance_NUIQ;
% get_UCCS_enhance_NUIQ;



load("CUIS_NUIQ_array");
load("SAUD_NUIQ_array");
load("UIEB_NUIQ_array");
load("UIQS_NUIQ_array");
load("UCCS_NUIQ_array");

data_array = [];
CUIS_silgt_NUIQ = mean(CUIS_NUIQ_array(:,1:200),2);
data_array = [data_array,CUIS_silgt_NUIQ];

CUIS_general_NUIQ = mean(CUIS_NUIQ_array(:,201:800),2);
data_array = [data_array,CUIS_general_NUIQ];

CUIS_severe_NUIQ = mean(CUIS_NUIQ_array(:,801:1000),2);
data_array = [data_array,CUIS_severe_NUIQ];

SAUD_NUIQ = mean(SAUD_NUIQ_array,2);
data_array = [data_array,SAUD_NUIQ];

UIEB_NUIQ = mean(UIEB_NUIQ_array,2);
data_array = [data_array,UIEB_NUIQ];

UIQS_NUIQ = mean(UIQS_NUIQ_array,2);
data_array = [data_array,UIQS_NUIQ];

UCCS_bg_NUIQ = mean(UCCS_bg_NUIQ_array,2);
data_array = [data_array,UCCS_bg_NUIQ];

UCCS_blue_NUIQ = mean(UCCS_BLUE_NUIQ_array,2);
data_array = [data_array,UCCS_blue_NUIQ];

UCCS_green_NUIQ = mean(UCCS_GREEN_NUIQ_array,2);
data_array = [data_array,UCCS_green_NUIQ];

data_head = {'slight','general','severe','SAUD','UIEB','UIQS','UCCS_bg','UCCS_BLUE','UCCS_GREEN'};

all_data_dir = [data_head;num2cell(data_array)];

save('all_data_dir',"all_data_dir");

% 保存为Excel文件（.xlsx格式）
writecell(all_data_dir, 'output.xlsx');



