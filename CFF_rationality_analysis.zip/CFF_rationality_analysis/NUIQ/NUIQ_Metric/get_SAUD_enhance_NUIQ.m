clc,clear;

load("path_data.mat");


SAUD_NUIQ_array= [];
groups = 1;
numbers_in_each_group = 100;

for i = 1:11
    for j = 1:100
        im = imread([SAUD_path_data{i},num2str(j),'.png']);
        final_feature(j,:) = NUIQ_feature_extraction(im);
        fprintf('SAUD end %d:%d\n',i,j);
    end
    final_feature = final_feature';
    final_feature = mapminmax(final_feature,0,1);
    final_feature = final_feature';
    %% score prediction
    quality = test_model(final_feature,groups,numbers_in_each_group);
    SAUD_NUIQ_array(i,:) = quality';
end

save('SAUD_NUIQ_array',"SAUD_NUIQ_array");



