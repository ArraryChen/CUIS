clc,clear;

load("path_data.mat");

UIEB_NUIQ_array= [];
groups = 1;
numbers_in_each_group = 950;

for i = 1:11
    for j = 1:950
        im = imread([UIEB_path_data{i},'after\',num2str(j),'.png']);
        final_feature(j,:) = NUIQ_feature_extraction(im);
        fprintf('UIEB end %d:%d\n',i,j);
    end
    final_feature = final_feature';
    final_feature = mapminmax(final_feature,0,1);
    final_feature = final_feature';
    %% score prediction
    quality = test_model(final_feature,groups,numbers_in_each_group);
    UIEB_NUIQ_array(i,:) = quality';
end

save('UIEB_NUIQ_array',"UIEB_NUIQ_array");