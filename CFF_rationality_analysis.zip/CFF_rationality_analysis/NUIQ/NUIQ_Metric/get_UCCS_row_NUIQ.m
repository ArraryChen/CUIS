clc,clear;

groups = 1;
numbers_in_each_group = 100;

UCCS_bg_NUIQ_row_array= [];

for j = 1:100
    if j-1<10
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','bg_','0',num2str(j-1),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','bg_',num2str(j-1),'.jpg'];
    end

    im = imread(im_name);
    final_feature(j,:) = NUIQ_feature_extraction(im);
    fprintf('end %d\n',j);
end
final_feature = final_feature';
final_feature = mapminmax(final_feature,0,1);
final_feature = final_feature';
%% score prediction
quality = test_model(final_feature,groups,numbers_in_each_group);
UCCS_bg_NUIQ_row_array = [UCCS_bg_NUIQ_row_array,quality'];





UCCS_blue_NUIQ_row_array= [];

for j = 1:100
    if j-1<10
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','blue_','0',num2str(j-1),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','blue_',num2str(j-1),'.jpg'];
    end

    im = imread(im_name);
    final_feature(j,:) = NUIQ_feature_extraction(im);
    fprintf('end %d\n',j);
end

final_feature = final_feature';
final_feature = mapminmax(final_feature,0,1);
final_feature = final_feature';
%% score prediction
quality = test_model(final_feature,groups,numbers_in_each_group);
UCCS_blue_NUIQ_row_array = [UCCS_blue_NUIQ_row_array,quality'];





UCCS_green_NUIQ_row_array= [];


for j = 1:100
    if j-1<10
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','green_','0',num2str(j-1),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UCCS\before\','green_',num2str(j-1),'.jpg'];
    end

    im = imread(im_name);
    final_feature(j,:) = NUIQ_feature_extraction(im);
    fprintf('end %d\n',j);
end
final_feature = final_feature';
final_feature = mapminmax(final_feature,0,1);
final_feature = final_feature';
%% score prediction
quality = test_model(final_feature,groups,numbers_in_each_group);
UCCS_green_NUIQ_row_array = [UCCS_green_NUIQ_row_array,quality'];


save('UCCS_NUIQ_row_array','UCCS_bg_NUIQ_row_array','UCCS_blue_NUIQ_row_array','UCCS_green_NUIQ_row_array');