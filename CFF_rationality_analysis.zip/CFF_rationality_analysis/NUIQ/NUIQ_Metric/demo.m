clc;clear all;

% addpath('F:\image_enhancement\CFF_rationality_analysis\tools\FDUM\Code-for-FDUM-method\Code');
% load("path_data.mat");

%% para_set
%% for ten enhanced images of one raw image:groups = 1; numbers_in_each_group = 10;
%% for ten enhanced images of ten raw image:groups = 10; numbers_in_each_group = 1;
% groups = 1;
% numbers_in_each_group = 7;
% %% feature extraction
% for i=1:7
% I = imread(['/Users/jianie/Desktop/test',num2str(i),'.png']);
% final_feature(i,:) = NUIQ_feature_extraction(I);
% end
% final_feature = final_feature';
% final_feature = mapminmax(final_feature,0,1);
% final_feature = final_feature';
% %% score prediction
% predictions = test_model(final_feature,groups,numbers_in_each_group);

%% para_set
%% for ten enhanced images of one raw image:groups = 1; numbers_in_each_group = 10;
%% for ten enhanced images of ten raw image:groups = 10; numbers_in_each_group = 1;
%% para_set
%% for ten enhanced images of one raw image:groups = 1; numbers_in_each_group = 10;
%% for ten enhanced images of ten raw image:groups = 10; numbers_in_each_group = 1;
groups = 1;
numbers_in_each_group = 200;
%% feature extraction
for i=1:200
    % I = imread(['F:\image_enhancement\UIE\Dataset-CUIS\CUIS-2\fusion-based-1\',num2str(i),'.png']);
    I = imread(['F:\image_enhancement\RGHS\CUIE\',num2str(i),'.png']);
    final_feature(i,:) = NUIQ_feature_extraction(I);
    fprintf('end %d\n',i);
end
final_feature = final_feature';
final_feature = mapminmax(final_feature,0,1);
final_feature = final_feature';
%% score prediction
predictions = test_model(final_feature,groups,numbers_in_each_group);
mean(predictions)






