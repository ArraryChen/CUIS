clc,clear;

groups = 1;
numbers_in_each_group = 726;

UIQS_NUIQ_row_array= [];

for j = 1:726
    if (0<j) && (j<10)
        im_name = ['F:\image_enhancement\UIE\Dataset-UIQS\before\','C_','00',num2str(j),'.jpg'];
    elseif (9<j) && (j<100)
        im_name = ['F:\image_enhancement\UIE\Dataset-UIQS\before\','C_','0',num2str(j),'.jpg'];
    else
        im_name = ['F:\image_enhancement\UIE\Dataset-UIQS\before\','C_',num2str(j),'.jpg'];
    end

    im = imread(im_name);
    final_feature(j,:) = NUIQ_feature_extraction(im);
    fprintf('end %d\n',j);
end

final_feature = final_feature';
final_feature = mapminmax(final_feature,0,1);
final_feature = final_feature';
%% score prediction
quality = test_model(final_feature,groups,numbers_in_each_group);
UIQS_NUIQ_row_array = [UIQS_NUIQ_row_array,quality'];


save('UIQS_NUIQ_row_array','UIQS_NUIQ_row_array');

