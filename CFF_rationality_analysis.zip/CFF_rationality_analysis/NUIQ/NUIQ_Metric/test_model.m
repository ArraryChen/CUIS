function [predictions] = test_model(feature,groups,numbers_in_each_group)
%% test model
test_data = feature;
% test_label = d(801:1000,:);
test_label = zeros(groups * numbers_in_each_group,1);

fid2=fopen('F:\image_enhancement\CFF_rationality_analysis\NUIQ\NUIQ_Metric\test.dat','w');
dat_creat(test_label,test_data,fid2,59,groups,numbers_in_each_group);
fclose(fid2);

system('svm_rank_classify.exe test.dat model predictions');
load predictions
end

